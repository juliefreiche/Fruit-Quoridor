package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import tools.dijkstra.DijkstraAlgorithm;
import tools.dijkstra.model.Edge;
import tools.dijkstra.model.Graph;
import tools.dijkstra.model.Vertex;

public class Plateau implements BoardGames {

	private Jeu jeuOrange;
	private Jeu jeuVert;
	private Jeu jeuCourant, jeuOppose;
	private String message;
	private List<Mur> murGeneral;

	private List<Vertex> nodes;
	private List<Edge> edges;
	private List<Edge> testEdges;

	public Plateau() {
		super();
		this.message="";
		this.jeuOrange = new Jeu(Couleur.ORANGE, 4, 0);
		this.jeuVert = new Jeu(Couleur.VERT, 4, 8);
		this.jeuCourant = this.jeuOrange;
		this.jeuOppose = this.jeuVert;
		this.murGeneral = new ArrayList<Mur>();
		nodes = new ArrayList<Vertex>();
		edges = new ArrayList<Edge>();

		// creation des cases du plateau
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				Vertex location = new Vertex("Node_" + i + j);
				nodes.add(location);
			}
		}
		// System.out.println("taille de la liste (node : 81) : " + nodes.size());

		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				// System.out.println("i = " + i + " et j = " + j);
				if (j < 8) // add vertical edge
				{
					addLane(i + "" + j + "" + i + "" + (j + 1) + "aller", i * 9 + j, i * 9 + j + 1, 1);
					addLane(i + "" + j + "" + i + "" + (j + 1) + "retour", i * 9 + j + 1, i * 9 + j, 1);
				}
				if (i < 8) {
					addLane(i + "" + j + "" + (i + 1) + "" + j + "aller", i * 9 + j, i * 9 + j + 9, 1);
					addLane(i + "" + j + "" + (i + 1) + "" + j + "retour", i * 9 + j + 9, i * 9 + j, 1);
				}

			}
		}

		testEdges = new ArrayList<Edge>(edges);
		// edges : 144 * 2 (aller retour => deux fois plus) = 288 connections
	}

	public String getJsonPlateau()
	{
		
		 String positionO = jeuOrange.getX()+""+jeuOrange.getY();

		 String positionV = jeuVert.getX()+""+jeuVert.getY();
		 
		String couleur = getColorCurrentPlayer().name();
		String murs = "[";
		for (Mur mur: murGeneral)
		{
			murs+=mur.toString()+",";
		}
		if(murs.length()>1)
			murs.substring(0, murs.length()-2);
		murs+="]";
		int mursRestantsO = 10-jeuOrange.getMurPoses().size();
		int mursRestantsV = 10-jeuVert.getMurPoses().size();
		String json = "{\"joueurOrange\":\""+positionO+"\","+"\"joueurVert\":\""+positionV+"\",\"joueurCourant\":\""+couleur+"\",\"murs\":"+murs+",\"mursRestantsOrange\":"+mursRestantsO+",\"mursRestantsVert\":"+mursRestantsV+"}";
		
		
		return json;
		
	}
	
	@Override
	public boolean move(int x, int y) {
		this.jeuCourant.move(x, y);
		//this.setMessage("OK : déplacement effectué ");
		switchJoueur();
		return true;
	}

	@Override
	public boolean isMoveOk(int xFinal, int yFinal) {
		int x = this.jeuCourant.getX();
		int y = this.jeuCourant.getY();
		int xo = this.jeuOppose.getX();
		int yo = this.jeuOppose.getY();

		boolean isJumpOk = false;

		if (xo == xFinal && yo == yFinal) // on ne peut pas etre sur la meme case qu'un autre pion
		{
			this.message="Les pions ne peuvent pas se chevaucher !";
			return false;
		}
		// On verifie que le joueur peut bien sauter par dessus un autre pion
		if (y == yFinal && y==yo && Math.abs(x - xFinal) == 2 && ((x < xo && xo < xFinal) || (x > xo && xo > xFinal))) {
			isJumpOk = true;
			x = xo;
			y = yo;
		}

		else if (x == xFinal && x==xo && Math.abs(y - yFinal) == 2 && ((y < yo && yo < yFinal) || (y > yo && yo > yFinal))) {
			isJumpOk = true;
			x = xo;
			y = yo;
		}

		else if (Math.abs(x - xFinal) == 1 && Math.abs(y - yFinal) == 1 && (yo == yFinal || xo == xFinal)) {
			isJumpOk = true;
			x = xo;
			y = yo;
		}

		boolean depPion = this.jeuCourant.isMoveOk(xFinal, yFinal, isJumpOk);

		if (!depPion)
		{
			this.message = "Mouvement non valide !";
			return false;
		}
			

		boolean ret = true;
		// On verifie si il n'y a pas de murs sur la trajectoire du pion
		if (xFinal < x) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				if (x == xp1 && xp1 == xp2 && yp1 <= y && y < yp2)
				{
					ret= false;
					break;
				}
			}
		} else if (xFinal > x) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				if (xFinal == xp1 && xp1 == xp2 && yp1 <= y && y < yp2)
				{
					ret= false;
					break;
				}
			}
		} else if (y < yFinal) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				if (yFinal == yp1 && yp1 == yp2 && xp1 <= x && x < xp2 )
					{
					ret= false;
					break;
					}
			}
		} else if (y > yFinal) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				if (y == yp1 && yp1 == yp2 && xp1 <= x && x < xp2 )
					{
					ret= false;
					break;
					}
			}
		}
		/*
		 * // On verifie si il n'y a pas de murs sur la trajectoire du pion
		if (x < xFinal) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				if (yp1 < y && y < yp2 && xFinal == xp1)
					ret= false;
			}
		} else if (x > xFinal) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				if (yp1 < y && y < yp2 && x == xp1)
					ret= false;
			}
		} else if (y < yFinal) {
			for (Mur mur : murGeneral) {
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				int yp1 = mur.getY1();
				if (xp1 < x && x < xp2 && yFinal == yp1)
					ret= false;
			}
		} else if (y > yFinal) {
			for (Mur mur : murGeneral) {
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				int yp1 = mur.getY1();
				if (xp1 < x && x < xp2 && y == yp1)
					ret= false;
			}
		}
		 */
		
		if(!ret)
			this.message="Un mur vous bloque !";
		return ret;
	}

	@Override
	public void switchJoueur() {
		if (this.jeuCourant == this.jeuOrange) {
			this.jeuCourant = this.jeuVert;
			this.jeuOppose = this.jeuOrange;
		} else {
			this.jeuCourant = this.jeuOrange;
			this.jeuOppose = this.jeuVert;
		}
		//this.setMessage("Changement de joueur");
	}

	@Override
	public boolean isEnd() {
		if (this.jeuOrange.getY() == 8)
			return true;
		if (this.jeuVert.getY() == 0)
			return true;
		return false;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

	/*private void setMessage(String message) {
		this.message = message;
	}*/

	@Override
	public Couleur getColorCurrentPlayer() {
		return this.jeuCourant.getCouleur();
	}

	@Override
	public boolean put(int x1, int y1, int x2, int y2) {
		this.jeuCourant.put(x1, y1, x2, y2);
		Mur mur = new Mur();
		mur.put(x1, y1, x2, y2);
		this.murGeneral.add(mur);
		//this.setMessage("OK : mur plac� ");
		switchJoueur();
		return true;
	}

	@Override
	public boolean isPutOk(int x1, int y1, int x2, int y2) {
		this.message="";
		boolean ret = true;
		for (Mur mur : murGeneral) {
			int xp1 = mur.getX1();
			int xp2 = mur.getX2();
			int yp1 = mur.getY1();
			int yp2 = mur.getY2();

			if(x1 == xp1 && x2 == xp2 && y1 == yp1 && y2 == yp2)
			{
				ret = false;
			}
			if (x1 == x2 && x2 > xp1 && x2 < xp2) // test si mur se coupent
			{
				if (yp1 == yp2 && yp2 > y1 && yp2 < y2)
					ret = false;
			}

			if (y1 == y2 && y2 > yp1 && y2 < yp2) // test si mur se coupent
			{
				if (xp1 == xp2 && xp2 > x1 && xp2 < x2)
					ret = false;
			}

			if (x1 == x2 && x2 == xp2 && xp2 == xp1) // test si mur vertical chevauchement
			{
				if ((yp1 < y1 && y1 < yp2) || (yp1 < y2 && y2 < yp2))
					ret = false;
			} else if (y1 == y2 && y2 == yp2 && yp2 == yp1) // test si mur horizontal chevauchement
			{
				//System.out.println("coord : "+x1+);
				if ((xp1 < x1 && x1 < xp2) || (xp1 < x2 && x2 < xp2))
					ret = false;
			}
			// Rien ne sert de continuer si on sait que c'est déja plus ok ( mur mal
			// positionné)
			if (!ret)
				break;
		}

		if(!ret)
		{
			this.message="Le mur chevauche un autre mur";
		}
		else if (!this.jeuCourant.isPutOk(x1, y1, x2, y2))// teste si le mur est bon
		{
			ret = false;
			this.message="Le mur ne peut pas �tre pos� au bord (+ la longueur du mur = 2 )";

		}

		if (ret) // si le mur pose ne chevauche aucun autre mur, on va tester si il ne bloque
		// aucun joueur avec l'algorithme dijkstra
		{
			int xOrange = jeuOrange.getX();
			int yOrange = jeuOrange.getY();
			int positionOrange = xOrange * 9 + yOrange; // voir le tableau excel des nodes ( cases )
			int xVert = jeuVert.getX();
			int yVert = jeuVert.getY();
			int positionVert = xVert * 9 + yVert;

			if (y1 == y2) // si mur horizontal
			{
				// deux liens à détruire dans les deux sens => 4 removals
				// String id = x1;
				// String id_coord=x1+y1+x1+(y1+1);

				removeLane(testEdges, x1 + "" + (y1 - 1) + "" + x1 + "" + y1 + ""); // très prise de tête pour
																					// comprendre
				removeLane(testEdges, (x1 + 1) + "" + (y1 - 1) + "" + (x1 + 1) + "" + y1 + "");
			} else // mur vertical
			{
				removeLane(testEdges, (x1 - 1) + "" + y1 + "" + x1 + "" + y1 + "");
				removeLane(testEdges, (x1 - 1) + "" + (y1 + 1) + "" + x1 + "" + (y1 + 1) + "");

			}
			Graph graph = new Graph(nodes, testEdges);
			DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(graph);

			// On commence par le pion vert, on teste s'il peut aller sur sa ligne de
			// victoire
			dijkstra.execute(nodes.get(positionVert)); // défini le coût de chaque node
			// on assume que c'est faux, s'il y a un chemin (path != null ) on met ret à
			// true
			ret = false;
			for (int i = 0; i < 9; i++) {

				LinkedList<Vertex> path = dijkstra.getPath(nodes.get(i * 9)); // vert gagne sur y = 0 (voir tableau
																				// excel)
				if (path != null) {
					ret = true;
					break; // inutile de continuer à boucler
				}
			}

			if (ret) {
				// on regarde maintenant pour l'autre joueur ( orange) }
				dijkstra.execute(nodes.get(positionOrange)); // défini le coût de chaque node
				// on assume que c'est faux, s'il y a un chemin (path != null ) on met ret à
				// true
				ret = false;
				for (int i = 0; i < 9; i++) {

					LinkedList<Vertex> path = dijkstra.getPath(nodes.get(i * 9 + 8));// orange gagne sur y = 8
					if (path != null) {
						ret = true;
						break; // inutile de continuer à boucler
					}
				}
			}
		}

		if (ret) // si OK : on met à jour notre liste de liens (edges)
		{
			if (y1 == y2) // si mur horizontal
			{
				// deux liens à détruire dans les deux sens => 4 removals
				// String id = x1;
				// String id_coord=x1+y1+x1+(y1+1);

				removeLane(edges, x1 + "" + (y1 - 1) + "" + x1 + "" + y1 + ""); // très prise de tête pour comprendre
				removeLane(edges, (x1 + 1) + "" + (y1 - 1) + "" + (x1 + 1) + "" + y1 + "");
			} else // mur vertical
			{
				removeLane(edges, (x1 - 1) + "" + y1 + "" + x1 + "" + y1 + "");
				removeLane(edges, (x1 - 1) + "" + (y1 + 1) + "" + x1 + "" + (y1 + 1) + "");

			}
		} else {
			// sinon on réinitialise testEdges avec la précédente valeur
			testEdges = new ArrayList<Edge>(edges);
			if(this.message.equals("")) // si le message est vide
				this.message="Le mur bloque un autre joueur";

		}

		return ret;
	}

	private void addLane(String laneId, int sourceLocNo, int destLocNo, int duration) {
		// System.out.println(sourceLocNo);
		Edge lane = new Edge(laneId, nodes.get(sourceLocNo), nodes.get(destLocNo), duration);
		edges.add(lane);
	}

	private void removeLane(List<Edge> liste, String laneId) {
		// System.out.println(sourceLocNo);
		// Edge lane = new Edge(laneId,nodes.get(sourceLocNo), nodes.get(destLocNo),
		// duration );
		// System.out.println("laneID : " + laneId);
		// System.out.println(liste.size());
		LinkedList<Edge> intermediaire = new LinkedList();
		for (Edge e : liste) {
			// System.out.println("e.id : "+ e.getId() + " , recu : "+ laneId);
			if (e.getId().contains(laneId)) {
				intermediaire.add(e);
				// liste.remove(e);
			}
		}
		for (Edge e : intermediaire) {
			liste.remove(e);
		}
		// liste.removeIf(p -> p.getId()==laneId + "aller");
		// liste.removeIf(p -> p.getId()==laneId + "retour");
		// System.out.println(liste.size());
		// edges.add(lane);
	}

	public static void main(String[] args) {
		System.out.println("Hello World!"); // Display the string.
		Plateau plateau = new Plateau();

		// Tests position des murs
		/*if (plateau.isPutOk(1, 0, 1, 2)) {
			plateau.put(1, 0, 1, 2);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(0);
			System.out.println("Le mur 0 est posé " + mur.toString());
		}

		if (plateau.isPutOk(1, 2, 3, 2)) {
			plateau.put(1, 2, 3, 2);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 1 est posé " + mur.toString());
		}

		if (plateau.isPutOk(3, 2, 5, 2)) {
			plateau.put(3, 2, 5, 2);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(2);
			System.out.println("Le mur 2 est posé " + mur.toString());
		}

		if (plateau.isPutOk(3, 0, 3, 2)) {
			plateau.put(3, 0, 3, 2);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(3);
			System.out.println("Le mur 3 est posé " + mur.toString());
		}

		if (plateau.isPutOk(5, 1, 5, 3)) {
			plateau.put(5, 0, 5, 2);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 4 est posé " + mur.toString());
		}
		if (plateau.isPutOk(5, 3, 7, 3)) {
			plateau.put(5, 3, 7, 3);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 5 est posé " + mur.toString());
		}
		if (plateau.isPutOk(7, 3, 9, 3)) {
			plateau.put(7, 3, 9, 3);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 6 est posé " + mur.toString());
		}
		if (plateau.isPutOk(7, 3, 7, 5)) {
			plateau.put(7, 3, 7, 5);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 7 est posé " + mur.toString());
		}
		if (plateau.isPutOk(7, 5, 7, 7)) {
			plateau.put(7, 5, 7, 7);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 8 est posé " + mur.toString());
		}
		if (plateau.isPutOk(7, 7, 7, 9)) {
			plateau.put(7, 7, 7, 9);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 9 est posé " + mur.toString());
		}
		if (plateau.isPutOk(7, 8, 9, 8)) {
			plateau.put(7, 8, 9, 8);
			Mur mur = new Mur();
			mur = plateau.murGeneral.get(1);
			System.out.println("Le mur 10 est posé " + mur.toString());
		}
*/
		/*
		 * if (plateau.isPutOk(2, 1, 2, 3)) { plateau.put(2, 1, 2, 3); Mur mur = new
		 * Mur(); mur = plateau.murGeneral.get(1);
		 * System.out.println("Le mur 3 est posé " + mur.toString()); }
		 * 
		 * if (plateau.isPutOk(1, 2, 1, 4)) { plateau.put(1, 2, 1, 4); Mur mur = new
		 * Mur(); mur = plateau.murGeneral.get(3);
		 * System.out.println("Le mur 4 est posé " + mur.toString()); }
		 * 
		 * if (plateau.isPutOk(1, 3, 1, 5)) { plateau.put(1, 3, 1, 5); Mur mur = new
		 * Mur(); mur = plateau.murGeneral.get(1);
		 * System.out.println("Le mur 5 est posé " + mur.toString()); }
		 * 
		 * if (plateau.isPutOk(0, 3, 2, 3)) { plateau.put(0, 3, 2, 3); Mur mur = new
		 * Mur(); mur = plateau.murGeneral.get(1);
		 * System.out.println("Le mur 6 est posé " + mur.toString()); }
		 */

		// Tests deplacements pions
		if (plateau.isMoveOk(4, 1)) {
			plateau.move(4, 1);
			System.out.println(plateau.jeuOppose.toString());
			
		}
		

	}

}