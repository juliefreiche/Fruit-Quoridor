package model;


/**
 * @author francoise.perrin
 * 
 * Cette interface d�fini le comportement attendu 
 * des jeux de plateaux
 *
 */
public interface BoardGames {	

	/**
	 * Permet de deplacer une piece connaissant ses coordonnees initiales 
	 * vers ses coordonnees finales 	 *  
	 * @param xInit
	 * @param yInit
	 * @param xFinal
	 * @param yFinal
	 * @return OK si deplacement OK	 
	 */
	public boolean isMoveOk(int x, int y);
	public void switchJoueur();
	public boolean move ( int x, int y);

	/**
	 * @return true si c'est la fin du jeu
	 */
	public boolean isEnd();

	//public List<PieceIHMs> getPiecesIHM();
	/**
	 * @return un message sur l'�tat du jeu
	 */
	public String getMessage();

	/**
	 * @return la couleur du jouer courant
	 */
	public Couleur getColorCurrentPlayer();
	
	/**
	 * @param x
	 * @param y
	 * @return la couleur de la pi�ce s�lectionn�e
	 */
	//public Couleur getPieceColor(int x, int y);
	public boolean isPutOk(int x1, int y1, int x2, int y2);
	
	public boolean put(int x1, int y1, int x2, int y2) ;
	
	public String getJsonPlateau();
	
}
