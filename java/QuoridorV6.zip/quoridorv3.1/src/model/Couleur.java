package model;

public enum Couleur {
	JAUNE, VERT, ORANGE , ROUGE
}
