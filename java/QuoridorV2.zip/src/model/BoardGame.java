package model;

public interface BoardGame {

	public boolean move (int x, int y); 
	
	public boolean isMoveOk (int x, int y); 
	
	public boolean put(int x1, int y1, int x2, int y2);
	
	public boolean isPutOk(int x1, int y1, int x2, int y2);
	
	public void switchJoueur();

	//retourne true si le jeu est fini
	public boolean isEnd();

	//retourne un message sur l'etat du jeu
	public String getMessage();

	//couleur du joueur courant
	public Couleur getColorCurrentPlayer();
	
	//public List<PieceIHM> getPiecesIHM();
	
	//public Couleur getPieceColor(int x, int y);
}
