package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Plateau implements BoardGame {

	private Jeu jeuOrange;
	private Jeu jeuVert;
	private Jeu jeuCourant, jeuOppose;
	private String message;
	private List<Mur> murGeneral;
	
	public Plateau() {
		super();
		this.jeuOrange = new Jeu(Couleur.ORANGE, 5, 0);
		this.jeuVert = new Jeu(Couleur.VERT, 5, 10);
		this.jeuCourant = this.jeuOrange;
		this.jeuOppose = this.jeuVert;
		this.murGeneral = new ArrayList<Mur>();
	}
	
	@Override
	public boolean move(int x, int y) {
		this.jeuCourant.move(x, y);
		this.setMessage("OK : déplacement effectué "); 
		return true;
	}

	@Override
	public boolean isMoveOk(int xFinal, int yFinal) {
		int x = this.jeuCourant.getX();
		int y = this.jeuCourant.getY();
		
		if(x==xFinal-1)
			return true;
		return false;
	}

	@Override
	public void switchJoueur() {
		if (this.jeuCourant == this.jeuOrange) {
			this.jeuCourant = this.jeuVert;
			this.jeuOppose = this.jeuOrange;
		} else {
			this.jeuCourant = this.jeuOrange;
			this.jeuOppose = this.jeuVert;
		}

	}

	@Override
	public boolean isEnd() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getMessage() {
		return this.message;
	}
	
	private void setMessage(String message) {
		this.message = message;
	}

	@Override
	public Couleur getColorCurrentPlayer() {
		return this.jeuCourant.getCouleur();
	}

	@Override
	public boolean put(int x1, int y1, int x2, int y2) {
		this.jeuCourant.put(x1, y1, x2, y2);
		this.setMessage("OK : déplacement effectué ");
		return true;
	}

	@Override
	public boolean isPutOk(int x1, int y1, int x2, int y2) {
		 for(Iterator it=murGeneral.iterator(); it.hasNext();) {
			 System.out.println(it.next()); 
		 }
		return false;
	}

}
