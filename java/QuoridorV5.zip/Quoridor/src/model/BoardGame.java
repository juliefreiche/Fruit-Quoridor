package model;

public interface BoardGame {

	public boolean move(int x, int y);

	public boolean isMoveOk(int xFinal, int yFinal);

	public void switchJoueur();

	public boolean isEnd();

	public String getMessage();

	public Couleur getColorCurrentPlayer();

	public boolean put(int x1, int y1, int x2, int y2);
	
	public boolean isPutOk(int x1, int y1, int x2, int y2);
}
