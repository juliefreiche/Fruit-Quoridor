package controler;

import model.Quoridor;

public class QuoridorControler {

	private Quoridor qrd;
	
	public QuoridorControler()
	{
		qrd = new Quoridor();
	}
	
	public boolean move(int x, int y)
	{
		
		return qrd.move(x, y);
	}

	
	
}
