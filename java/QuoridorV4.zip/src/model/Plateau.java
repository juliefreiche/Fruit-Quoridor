package model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Plateau implements BoardGames {

	private Jeu jeuOrange;
	private Jeu jeuVert;
	private Jeu jeuCourant, jeuOppose;
	private String message;
	private List<Mur> murGeneral;

	public Plateau() {
		super();
		this.jeuOrange = new Jeu(Couleur.ORANGE, 5, 0);
		this.jeuVert = new Jeu(Couleur.VERT, 5, 10);
		this.jeuCourant = this.jeuOrange;
		this.jeuOppose = this.jeuVert;
		this.murGeneral = new ArrayList<Mur>();

	}

	@Override
	public boolean move(int x, int y) {
		this.jeuCourant.move(x, y);
		this.setMessage("OK : déplacement effectué ");
		return true;
	}

	@Override
	public boolean isMoveOk(int xFinal, int yFinal) {
		int x = this.jeuCourant.getX();
		int y = this.jeuCourant.getY();
		
		boolean isJumpOk = false;
		
		boolean depPion = this.jeuCourant.isMoveOk(x, y, isJumpOk);

		if(!depPion)
			return false;
		
		if (x < xFinal) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				if (yp1 < y && y < yp2 && xFinal == xp1)
					return false;
			}
		}
		else if (x > xFinal) {
			for (Mur mur : murGeneral) {
				int yp1 = mur.getY1();
				int yp2 = mur.getY2();
				int xp1 = mur.getX1();
				if (yp1 < y && y < yp2 && x == xp1)
					return false;
			}
		}
		else if (y < yFinal) {
			for (Mur mur : murGeneral) {
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				int yp1 = mur.getY1();
				if (xp1 < x && x < xp2 && yFinal == yp1)
					return false;
			}
		}
		else if (y > yFinal) {
			for (Mur mur : murGeneral) {
				int xp1 = mur.getX1();
				int xp2 = mur.getX2();
				int yp1 = mur.getY1();
				if (xp1 < x && x < xp2 && y == yp1)
					return false;
			}
		}
		return true;
	}

	@Override
	public void switchJoueur() {
		if (this.jeuCourant == this.jeuOrange) {
			this.jeuCourant = this.jeuVert;
			this.jeuOppose = this.jeuOrange;
		} else {
			this.jeuCourant = this.jeuOrange;
			this.jeuOppose = this.jeuVert;
		}

	}

	@Override
	public boolean isEnd() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getMessage() {
		return this.message;
	}

	private void setMessage(String message) {
		this.message = message;
	}

	@Override
	public Couleur getColorCurrentPlayer() {
		return this.jeuCourant.getCouleur();
	}

	@Override
	public boolean put(int x1, int y1, int x2, int y2) {
		this.jeuCourant.put(x1, y1, x2, y2);
		Mur mur = new Mur();
		mur.put(x1, x2, y1, y2);
		this.murGeneral.add(mur);
		this.setMessage("OK : déplacement effectué ");
		return true;
	}

	@Override
	public boolean isPutOk(int x1, int y1, int x2, int y2) {

		boolean ret = true;
		for (Mur mur : murGeneral) {
			int xp1 = mur.getX1();
			int xp2 = mur.getX2();
			int yp1 = mur.getY1();
			int yp2 = mur.getY2();
			// test si croisement entre deux murs
			if (x1 + y1 == xp1 + yp1 && x2 + y2 == xp2 + yp2) {
				ret = false;
			} else if (x1 == x2 && x2 == xp2 && xp2 == xp1) // test si mur vertical chevauchement
			{
				if ((yp1 < y1 && y1 < yp2) || (yp1 < y2 && y2 < yp2))
					ret = false;
			} else if (y1 == y2 && y2 == yp2 && yp2 == yp1) // test si mur horizontal chevauchement
			{
				if ((xp1 < x1 && x1 < xp2) || (xp1 < x2 && x2 < xp2))
					ret = false;
			} else if (!mur.isPutOk(x1, x2, y1, y2))// teste si le mur
			{
				ret = false;
			}

			// Rien ne sert de continuer si on sait que c'est déja plus ok ( mur mal
			// positionné)
			if (!ret)
				break;

		}

		if (ret) // si le mur pos� ne chevauche aucun autre mur, on va tester si il ne bloque
					// aucun joueur
		{

		}

		return ret;
	}

}
