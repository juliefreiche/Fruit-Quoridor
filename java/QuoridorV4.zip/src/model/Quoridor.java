package model;

public class Quoridor implements BoardGames {

	private BoardGames plateau;
	
	public Quoridor ()
	{
		plateau = new Plateau();
	}
	
	@Override
	public boolean isMoveOk(int x, int y) {
		
		return plateau.isMoveOk(x, y);
	}

	@Override
	public void switchJoueur() {
		plateau.switchJoueur();

	}

	@Override
	public boolean move(int x, int y)
	{
		
		if(isMoveOk(x,y))
		{
		 plateau.move(x, y);
		 return true;
		}
		else
			return false;
	}

	@Override
	public boolean isEnd() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getMessage() {
		return plateau.getMessage();
	}

	@Override
	public Couleur getColorCurrentPlayer() {
		return plateau.getColorCurrentPlayer();
	}

	@Override
	public boolean isPutOk(int x1, int y1, int x2, int y2) {
		
		return plateau.isPutOk(x1, y1, x2, y2);
	}

	@Override
	public boolean put(int x1, int y1, int x2, int y2) {
		
		return plateau.put(x1, y1, x2, y2);
	}

}
