package model;

public enum Couleur {
	JAUNE, VERT, ORANGE , ROUGE;
	
	//cette fonction permet d'�viter l'erreur java.lang.IllegalArgumentException dans quoridor controler
	public static Couleur convert(String str) {
        for (Couleur demoType : Couleur.values()) {
            if (demoType.toString().equals(str)) {
                return demoType;
            }
        }
        return null;
    }
}
