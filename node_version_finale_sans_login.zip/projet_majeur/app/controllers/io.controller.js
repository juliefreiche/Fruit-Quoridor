'use strict';
//var server = require("../../app.js");
//var io = require('socket.io')(server);
var utils = require('../utils/utils.js');
//var ContentModel = require('../models/content.model.js');
	var mysql = require('mysql');

function emitError(socket)
{
    console.log("connexion avec le serveur java tomcat impossible");
    socket.emit("erreur", "connexion avec le serveur java tomcat impossible");
}

this.listen = function(server, http)
{

    //var maMap = new Map();
    var local_games = new Map();
    //var local_games_by_socket_id = new Map();

    var online_games = new Map();

    var io = require('socket.io').listen(server);
    var queue_online_game = new Array();
    //options pour communiquer avec tomcat

    var options = {
        host: "localhost",
        port: 8080,
        path: "/test/HelloWord",
        method: "POST",
    };

    io.on('connection', function(socket)
    {
        console.log("connection");
        socket.emit('connection', socket.id); //JSON.stringify(socket));//
        socket.on('login',function(data){
	  		console.log("DATA RECUE login : ");
	  		console.log(data);
	  		//Verifier Login base de donnée
	  		//renvoyer succesAuth ou failAuth
	  		/*
				data = {
				email:
				password: ou id:
				}
				ou data = {
				name : 
				id : 
				}
	  		*/
	  		
	  		socket.emit('successAuth',true);
	  	});
	   
	    socket.on('logout',function(data){
	    	socket.emit('disconnect');
	    });
        /* socket.emit('news', { hello: 'world' });
         socket.on('my other event', function (data) {
           console.log(data);
         });
         */
        /*socket.on('data_comm', function (data) {
	    	console.log(data);
	    	//var msg = JSON.parse(data);

	    	maMap.set(data, socket);
	    	//enregistrer la socket dans une map, avec en clé l'id du client (qui est fourni dans le message)
	    	//console.log(maMap);

	    });*/
        socket.on('create_game', function(data)
        {
            console.log("DATA RECUE create_game : ");
            console.log(data);



            if (data == "local")
            {
                console.log(' creation local game en cours ');

                var uuid = utils.generateUUID();


                //{"nouvelle_partie":"oui","id":"101"}
                //creer une partie sur le server tomcat java ( http://shiya.io/send-http-requests-to-a-server-with-node-js/ )  //path: "/test/HelloWord",  
                /*headers: {
			        "Content-Type": "application/json"
			        "Authorization": "Bearer token"
			    }*/


                var req = http.request(options, function(res)
                {
                    var responseString = "";

                    res.on("data", function(data)
                    {

                        responseString += data;
                        // save all the data from response
                    });
                    /*req.fail(function(err) {
					    console.log("An error occurred." + util.inspect(err));
					    emitError();
					});*/

                    res.on("end", function()
                    {
                        // console.log("responseString : " );
                        //    console.log(responseString); 

                        var body = JSON.parse(responseString);

                        if (body.created == "true")
                        {
                            local_games.set(uuid, socket); // soit data.id soit uuid ????
                            //local_games_by_socket_id.set(socket.id,uuid);
                            socket.emit("local_game", uuid);
                            console.log("partie locale créée " + uuid);
                        }
                        // print to console when response ends
                    });

                });

                var reqBody = {
                    "nouvelle_partie": "oui",
                    "id": uuid
                };
                req.write(JSON.stringify(reqBody));

                req.on('error', function(err)
                {
                    emitError(socket);
                });
                req.end();
            }
            else if (data == "online")
            {
                console.log(' creation online game en cours ');
                //si qqun attend d'avoir un adversaire
                if (queue_online_game.length > 0)
                {
                	//vérification que la socket n'est pas déjà dans la queue
                	if(!queue_online_game.includes(socket))
                	{
                    //first in first out
                    var socketAdversaire = queue_online_game[0];
                    queue_online_game.splice(0,1); // on enlève le premier élément qu'on vient de récupérer
                    var uuid = utils.generateUUID();


                    //{"nouvelle_partie":"oui","id":"101"}
                    //creer une partie sur le server tomcat java ( http://shiya.io/send-http-requests-to-a-server-with-node-js/ )  //path: "/test/HelloWord",  
                    /*headers: {
			        "Content-Type": "application/json"
			        "Authorization": "Bearer token"
			    }*/


                    var req = http.request(options, function(res)
                    {
                        var responseString = "";

                        res.on("data", function(data)
                        {

                            responseString += data;
                            // save all the data from response
                        });
                        /*req.fail(function(err) {
					    console.log("An error occurred." + util.inspect(err));
					    emitError();
					});*/

                        res.on("end", function()
                        {
                            // console.log("responseString : " );
                            //    console.log(responseString); 

                            var body = JSON.parse(responseString);

                            if (body.created == "true")
                            {
                                var random = Math.floor((Math.random() * 10));
                                if (random % 2 == 0) // pas facile à factoriser
                                {

                                    //socketJO = socketJoueurOrange
                                    var jeu = {
                                        "socketJO": socketAdversaire,
                                        "socketJV": socket
                                    };
                                    var data_for_orange = {
                                        "joueur": "ORANGE",
                                        "id": uuid
                                    };
                                    var data_for_vert = {
                                        "joueur": "VERT",
                                        "id": uuid
                                    };
                                    online_games.set(uuid, jeu);
                                    socket.emit("online_game", data_for_vert);
                                    socketAdversaire.emit("online_game", data_for_orange);
                                }
                                else
                                {

                                    var jeu = {
                                        "socketJO": socket,
                                        "socketJV": socketAdversaire
                                    };
                                    var data_for_orange = {
                                        "joueur": "ORANGE",
                                        "id": uuid
                                    };
                                    var data_for_vert = {
                                        "joueur": "VERT",
                                        "id": uuid
                                    };
                                    online_games.set(uuid, jeu);
                                    socketAdversaire.emit("online_game", data_for_vert);
                                    socket.emit("online_game", data_for_orange);
                                    
                                }
                                console.log("partie online créée " + uuid);

                            }
                            // print to console when response ends
                        });

                    });

                    var reqBody = {
                        "nouvelle_partie": "oui",
                        "id": uuid
                    };
                    req.write(JSON.stringify(reqBody));

                    req.on('error', function(err)
                    {
                        emitError(socket);
                    });
                    req.end();
                    }
                    else
                    {
                    	socket.emit("erreur","vous êtes déjà dans la liste d'attente");
                    }
                }
                else
                {
                	console.log("Une personne attend un adversaire");
                    queue_online_game.push(socket); // on ajoute la socket à la liste d'attente
                }
            }
        });



        socket.on('move', function(data)
        {
            console.log("DATA RECUE MOVE : ");
            //console.log(data);
            //var slid = data;//JSON.parse(data);
            //vérification des coordonnées
            console.log(data);
            if ((data.coord.length == 2 || data.coord.length == 4) && (data.joueur.toUpperCase() == "ORANGE" || data.joueur.toUpperCase() == "VERT") && data.id != "")
            {

                //console.log("verif ok ");
                data.joueur = data.joueur.toUpperCase();

                var coup = data;
                //console.log("test map.get(indef): " +local_games.get("1") ); //test pour savoir comment ça réagit : resultat = undefined
                var game_id = data.id // local_games_by_socket_id.get(socket.id);
                var socket_legal = false;
                var game_type= "";

                // tester si la socket emetrice est la bonne 
                if (online_games.has(game_id))
                {
                	//console.log("online game id ok ");
                	game_type="online";
                    var jeu = online_games.get(game_id);
                    // vérification que la donnée reçue provient bien du bon joueur
                    if ((jeu.socketJO.id == socket.id && data.joueur == "ORANGE") || (jeu.socketJV.id == socket.id && data.joueur == "VERT"))
                    {
                        socket_legal = true;
                    }
                    else
                    {
                    	console.log("tentative triche (socket.id: "+socket.id +")");
                    }
                }
                else if(local_games.has(game_id))
                {
                	game_type="local";
                	if(socket.id == local_games.get(game_id).id)
                	{
                		socket_legal = true;
                	}
                }

                if (socket_legal)
                {

                    var req = http.request(options, function(res)
                    {
                        var responseString = "";
                        res.on("data", function(data)
                        {
                            responseString += data;
                            // save all the data from response
                        });

                        res.on("end", function()
                        {
                            // console.log("responseString : " );
                            console.log(responseString);

                            var body = JSON.parse(responseString);


                            if (body.action == "true")
                            {
                                var reponse = {
                                    "dernierCoup": coup,
                                    "jsonPlateau": body.jsonPlateau,
                                    "fin_partie":body.fin_partie

                                };

                                console.log("mouvement accepté pour partie " +game_type+" "+ game_id);
                                if (game_type=="local")
                                {
                                    socket.emit("move_ok", reponse);
                                   
                                }
                                else if (game_type=="online")
                                {
                                    var jeu = online_games.get(game_id);
                                    // vérification que la donnée reçue provient bien du bon joueur
                                    jeu.socketJO.emit("move_ok",reponse);
                                    jeu.socketJV.emit("move_ok",reponse);
                                }
                                if(body.fin_partie!="false")
                                {
                                	online_games.delete(game_id);
                                }



                            }
                            else
                            {
                                socket.emit("erreur", body.erreur); //on envoie que à la socket émétrice
                            }
                            // if created true = blabla 
                            //enregistrer la socket dans une map, avec en clé l'id du client (qui est fourni dans le message)


                            //var slid = data;//JSON.parse(data);
                            //vérification des coordonnées
                        });
                    });
                    req.on('error', function(err)
                    {
                        emitError(socket);
                    });
                    var reqBody = {
                        "coord": data.coord,
                        "joueur": data.joueur,
                        "id": game_id
                    };
                    //var reqBody = {"nouvelle_partie":"oui","id":uuid};
                    req.write(JSON.stringify(reqBody));

                    req.end();
                }
            }


        });
        // socket.on('slidEvent', function (data) {
        // 	console.log("DATA RECUE SLID EVENT : ");
        //  	console.log(data);
        //  	var slid = data;//JSON.parse(data);
        //  	if(slid.CMD== "START" || slid.CMD== "END" || slid.CMD== "BEGIN" || slid.CMD== "PREV" || slid.CMD== "NEXT" )
        //  	{
        //  		if(slid.CMD== "START")
        //  		{

        //  			ContentModel.read(slid.id, function (err, content) {
        // 				//content.src = "/contents/" + content.id; 
        //  				var content2={
        //  					"CMD" : sild.CMD,
        //  					"content" : content
        //  				}
        // 					sendToSockets(maMap, content2);


        //  			});
        //  		}
        //  		else
        //  		{
        //  			sendToSockets(maMap, slid);
        //  		}
        //  	}
        //  	else //PAUSE
        //  	{
        //  		sendToSockets(maMap, slid);
        //  	}

        // });


    });
}

var sendToSockets = function(map, content)
{
    var log = "sending to  : "
    for (var [id, socket] of map)
    {
        log += id + " ; ";
    }
    console.log(log);
    for (var [id, socket] of map)
    {
        socket.emit("currentSlidEvent", content);
    }

}

module.exports = this;