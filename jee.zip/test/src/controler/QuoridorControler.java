package controler;

import model.Couleur;
import model.Quoridor;

public class QuoridorControler {

	private Quoridor qrd;

	public QuoridorControler() {
		qrd = new Quoridor();
	}

	public boolean move(int x, int y) {

		return qrd.move(x, y);
	}

	public String getMessage() {
		return qrd.getMessage();
	}

	public boolean isEnd() {
		return qrd.isEnd();
	}

	public boolean isPlayerOK(String color) {
		// TODO Auto-generated method stub
		if (qrd.getColorCurrentPlayer().equals(Couleur.valueOf(color)))
			return true;
		else
			return false;
	}

	public boolean put(int x1, int y1, int x2, int y2) {
		return qrd.put(x1, y1, x2, y2);
	}
	public String getJsonPlateau()
	{
		return qrd.getJsonPlateau();
	}
}
