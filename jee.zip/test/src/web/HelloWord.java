package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import controler.QuoridorControler;

/**
 * Servlet implementation class HelloWord
 */
@WebServlet("/HelloWord")
public class HelloWord extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, QuoridorControler> parties;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HelloWord() {
		super();
		// TODO Auto-generated constructor stub
		parties = new HashMap<String, QuoridorControler>();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw = response.getWriter();
		pw.write("Hello world !");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// doGet(request, response);

		// methode 1 pour r�cup�rer body
		String body = request.getReader().lines().reduce("", (accumulator, actual) -> accumulator + actual);
		// methode 2
		// String body = request.getReader().lines().collect(Collectors.joining());

		// Transformation string json en objet java

		JSONParser parser = new JSONParser();
		JSONObject json = null;
		String coord = "";
		String joueur = "";
		//System.out.println(parties);
		// response.setContentType("application/json");
		// Get the printwriter object from response to write the required json object to
		// the output stream
		PrintWriter out = response.getWriter();
		JSONObject rep = new JSONObject();
		
		try {
			json = (JSONObject) parser.parse(body);
			String id = (String) json.get("id");
			//System.out.println((json.get("nouvelle_partie")));//.getClass().getName()));
			if (json.get("nouvelle_partie")!=null && json.get("nouvelle_partie").equals("oui")) {
				// Le node nous envoie lors d'une nouvelle partie l'id correspondant
				if (parties.containsKey(id)) {
					rep.put("erreur", "id d�j� pris");
				} else {
					parties.put(id, new QuoridorControler()); // cr�ation de la nouvelle partie et stockage dans le
																// hashmap
					rep.put("created", "true");
					rep.put("id", id);
				}

			} else {
				if (!parties.containsKey(id)) {
					rep.put("erreur", "partie inexistante");
				} else {

					rep.put("id", id);
					QuoridorControler qc = parties.get(id);

					coord = (String) json.get("coord");
					joueur = (String) json.get("joueur");

					if (!qc.isPlayerOK(joueur)) {
						rep.put("erreur", "ce n'est pas au tour du joueur " + joueur);
					} else {

						// teste la longueur de coord pour savoir si mur ou d�placement pion
						if (coord.length() > 2) {
							int x1 = Integer.parseInt(coord.substring(0, 1));
							int y1 = Integer.parseInt(coord.substring(1, 2));
							int x2 = Integer.parseInt(coord.substring(2, 3));
							int y2 = Integer.parseInt(coord.substring(3, 4));

							if (qc.put(x1, y1, x2, y2)) {
								rep.put("action", "true"); // action valid�e
								String stringPlateau = qc.getJsonPlateau();
								System.out.println("HELLO"+stringPlateau);
								JSONObject jsonPlateau = (JSONObject) parser.parse(qc.getJsonPlateau());
								rep.put("jsonPlateau", jsonPlateau);
								
							} else {
								rep.put("erreur", qc.getMessage());
							}

						} else {
							int x = Integer.parseInt(coord.substring(0, 1));
							int y = Integer.parseInt(coord.substring(1, 2));
							if (qc.move(x, y)) {
								rep.put("action", "true"); // action valid�e
								JSONObject jsonPlateau = (JSONObject) parser.parse(qc.getJsonPlateau());
								rep.put("jsonPlateau", jsonPlateau);
							} else {
								rep.put("erreur", qc.getMessage());
							}

						}
					}

				}

			}

		} catch (ParseException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// faire
/*
 * {"nouvelle_partie":"true","id":"001"}
 * {"id":"001","coord":"41","joueur":"ORANGE"}
 * 
 */
		// out.print(json.toJSONString());
		// out.print(coord);
		out.print(rep.toJSONString());
		out.flush();
	}
	
	private boolean isEnd(String id)
	{
		return parties.get(id).isEnd();
	}
	
	private JSONObject putJsonPlateau(JSONObject json)
	{
		return json;
	}
}
