var mysql = require('mysql');

var con = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "root"
});

con.connect(function(err) {
	if (err) throw err;
	console.log("Connected to mysql");
	con.query("CREATE DATABASE IF NOT EXISTS quoridor_db", function (err, result) {
		if (err) throw err;
		console.log("Database created");

		var con = mysql.createConnection({
			host: "localhost",
			user: "root",
			password: "root",
			database: "quoridor_db"
		});

		con.connect(function(err) {
			if (err) throw err;
			console.log("Connected to database quoridor_db");
			var sql = "CREATE TABLE IF NOT EXISTS user (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(15) DEFAULT NULL, email VARCHAR(50) DEFAULT NULL, password CHAR(128) DEFAULT NULL, facebook_id BIGINT(64) UNSIGNED DEFAULT NULL)";
			con.query(sql, function (err, result) {
				if (err) throw err;
				console.log("Table user created");

				var sql = 'CREATE TABLE games (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, id_user1 INT, id_user2 INT ,game_json VARCHAR(500), winner INT , FOREIGN KEY (`id_user1`) REFERENCES `user` (`id`) ON DELETE CASCADE,  FOREIGN KEY (`id_user2`) REFERENCES `user` (`id`) ON DELETE CASCADE , FOREIGN KEY (`winner`) REFERENCES `user` (`id`) ON DELETE CASCADE)';
				con.query(sql, function (err, result) {
					if (err) throw err;
					console.log("Table games created");
				});

			});



		});
	});


/*var sql = "CREATE TABLE stats (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, id_user1 INT NOT NULL FOREIGN KEY REFERENCES user(id), id_user2 INT NOT NULL FOREIGN KEY REFERENCES user(id) ,game_json VARCHAR(500) )";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table games created");
  });

  */
});