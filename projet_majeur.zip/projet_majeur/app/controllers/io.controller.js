'use strict';
//var server = require("../../app.js");
//var io = require('socket.io')(server);
var utils = require('../utils/utils.js');
//var ContentModel = require('../models/content.model.js');


this.listen = function(server,http)
{
	//var maMap = new Map();
	var local_games = new Map();
	var local_games_by_socket_id = new Map();
	var io = require('socket.io').listen(server);

	//options pour communiquer avec tomcat
	
	var options = {
	    host: "localhost",
	    port:8080,
	    path: "/test/HelloWord",
	    method: "POST",
	};

	io.on('connection', function (socket) {
		console.log("connection");
		socket.emit('connection',socket.id); //JSON.stringify(socket));//
		 /* socket.emit('news', { hello: 'world' });
		  socket.on('my other event', function (data) {
		    console.log(data);
		  });
		  */
	   	/*socket.on('data_comm', function (data) {
	    	console.log(data);
	    	//var msg = JSON.parse(data);

	    	maMap.set(data, socket);
	    	//enregistrer la socket dans une map, avec en clé l'id du client (qui est fourni dans le message)
	    	//console.log(maMap);

	  	});*/
	   	socket.on('create_game', function (data) {
	  		console.log("DATA RECUE local_game : ");
	    	console.log(data);

	    	if(data=="local")
	    	{
	    		console.log(' creation local game en cours ');
	    	}
	    	var uuid = utils.generateUUID();


	    	//{"nouvelle_partie":"oui","id":"101"}
	    	//creer une partie sur le server tomcat java ( http://shiya.io/send-http-requests-to-a-server-with-node-js/ )  //path: "/test/HelloWord",  
	    	 /*headers: {
			        "Content-Type": "application/json"
			        "Authorization": "Bearer token"
			    }*/
			

			var req = http.request(options, function (res) {
			    var responseString = "";

			    res.on("data", function (data) {
			    	
			        responseString += data;
			        // save all the data from response
			    });
			    res.on("end", function () {
			    	// console.log("responseString : " );
			     //    console.log(responseString); 

			        var body = JSON.parse(responseString);

				    if(body.created=="true")
				    {
				    	 local_games.set(uuid, socket); // soit data.id soit uuid ????
				    	 local_games_by_socket_id.set(socket.id,uuid);
		    			socket.emit("local_game",uuid);
		    			console.log("partie créée " + uuid);
				    }
			        // print to console when response ends
			    });
			 	
			    //console.log(res.body);
			   // 
			    // if created true = blabla 
			    //enregistrer la socket dans une map, avec en clé l'id du client (qui est fourni dans le message)
	    	

		    	//var slid = data;//JSON.parse(data);
		    	//vérification des coordonnées
			   
			});

			var reqBody = {"nouvelle_partie":"oui","id":uuid};
			req.write(JSON.stringify(reqBody));


			req.end();
	    	
	    	
	  	});



	  	socket.on('move', function (data) {
	  		console.log("DATA RECUE MOVE : ");
	    	//console.log(data);
	    	//var slid = data;//JSON.parse(data);
	    	//vérification des coordonnées
	    	console.log(data);
	    	if((data.coord.length== 2 || data.coord.length== 4 ) && (data.joueur.toUpperCase()== "ORANGE" || data.joueur.toUpperCase()== "VERT" ))
	    	{
	    		console.log("verif ok ")
	    		data.joueur = data.joueur.toUpperCase();
	    		//console.log("test map.get(indef): " +local_games.get("1") ); //test pour savoir comment ça réagit : resultat = undefined
	    		var game_id = local_games_by_socket_id.get(socket.id);

	    		var req = http.request(options, function (res) {
				    var responseString = "";

				 	 res.on("data", function (data) {
			    	
			        responseString += data;
			        // save all the data from response
				    });
				    res.on("end", function () {
				    	// console.log("responseString : " );
				         console.log(responseString); 

				        var body = JSON.parse(responseString);
					  

					    if(body.action=="true")
					 	{
			    			socket.emit("move_ok",body);
			    			console.log("mouvement accepté " + game_id);
					    }
					    else
					    {
					    	socket.emit("erreur",body.erreur);
					    }
					    // if created true = blabla 
					    //enregistrer la socket dans une map, avec en clé l'id du client (qui est fourni dans le message)
			    	

				    	//var slid = data;//JSON.parse(data);
				    	//vérification des coordonnées
				   	});
				});
	    		var reqBody={
						"coord" : data.coord,
						"joueur" : data.joueur,
						"id" : game_id
					};
				//var reqBody = {"nouvelle_partie":"oui","id":uuid};
				req.write(JSON.stringify(reqBody));

				req.end();    		
	    	}


	  	});
	  	// socket.on('slidEvent', function (data) {
	  	// 	console.log("DATA RECUE SLID EVENT : ");
	   //  	console.log(data);
	   //  	var slid = data;//JSON.parse(data);
	   //  	if(slid.CMD== "START" || slid.CMD== "END" || slid.CMD== "BEGIN" || slid.CMD== "PREV" || slid.CMD== "NEXT" )
	   //  	{
	   //  		if(slid.CMD== "START")
	   //  		{
	    			
	   //  			ContentModel.read(slid.id, function (err, content) {
    // 				//content.src = "/contents/" + content.id; 
	   //  				var content2={
	   //  					"CMD" : sild.CMD,
	   //  					"content" : content
	   //  				}
    // 					sendToSockets(maMap, content2);
    				

	   //  			});
	   //  		}
	   //  		else
	   //  		{
	   //  			sendToSockets(maMap, slid);
	   //  		}
	   //  	}
	   //  	else //PAUSE
	   //  	{
	   //  		sendToSockets(maMap, slid);
	   //  	}

	  	// });


	});
}

var sendToSockets = function(map, content)
{
	var log = "sending to  : "
	for(var [id, socket] of map)
	{
		log+=id+" ; ";
	}
	console.log(log);
	for(var [id, socket] of map)
	{
		socket.emit("currentSlidEvent", content);
	}

}

module.exports = this;