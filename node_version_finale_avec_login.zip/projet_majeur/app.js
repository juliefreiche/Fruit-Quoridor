'use strict';
//console.log('It Works !');
var fs = require("fs");
var mysql = require('mysql');
var http = require("http");
var CONFIG = require("./config.json"); //chemins absolus dans config.json pour pouvoir acceder au projet n'importe où
process.env.CONFIG = JSON.stringify(CONFIG);

/*
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root"
});
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to mysql database");
  con.query("DROP DATABASE quoridor_db", function (err, result) {
    if (err) throw err; 
    console.log("Result: " + result);
  });
});

*/
var mysql = require('mysql');

var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "root",
            database: "quoridor_db"
        });

var express = require("express");

var app = express();

var server = http.createServer(app);

server.listen(CONFIG.port, function() {
    var host = this.address().address;
    var port = this.address().port;
    console.log ( "Serveur écoute à l'adresse = \""+host+":"+port+"\"");
});

var path = require("path");
app.use("/", express.static(path.join(__dirname, "public")));

con.connect(function(err) {
    if (err) throw err;
    console.log("Connected to mysql");
    /*
    con.query("CREATE DATABASE IF NOT EXISTS quoridor_db", function (err, result) {
        if (err) throw err;
        console.log("Database created");

    });
    */
    //to get content from body !
    const bodyParser = require("body-parser");
    app.use(bodyParser.urlencoded({extended: true})); // npm install --save body-parser
    app.use(bodyParser.json());

    // init server
 
    var IOController = require("./app/controllers/io.controller.js");
    IOController.listen(server,http,con);
    
});
module.exports = server;