import React, { Component } from 'react';
import {connect} from 'react-redux'
import './menu.css';
import Jeu from '../jeu/jeu.js';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import data from '../../utils/language.json'
import {
  Route,
  NavLink,
  HashRouter
} from "react-router-dom";

class Menu extends Component {

  constructor(props) {
    super(props)
    this.handleClick = this.handleClick.bind(this);
    this.state = {
      activeIndex: 0,
      language: 0 ,
    }  
}
  
  handleClick(index, e) {

    this.setState({ activeIndex: index });
  }

render(){
	return(

<div className="row-offcanvas row-offcanvas-left col-md-2">
  <div id="sidebar" className="sidebar-offcanvas">
      <div className="col-md-12">
        <h3>Menu</h3>
        <ul className="nav nav-pills nav-stacked" >
          <li className={this.state.activeIndex===0 ? 'active': null}  onClick={this.handleClick.bind(this, 1)} id="jeu"><NavLink to="/">{data[this.state.language].jouer}</NavLink></li>
          <li className={this.state.activeIndex===1 ? 'active': null}  onClick={this.handleClick.bind(this, 1)} id="profil"><NavLink to="/profil">{data[this.state.language].profil}</NavLink></li>
          <li className={this.state.activeIndex===2 ? 'active': null}  onClick={this.handleClick.bind(this, 2)} id="parties"><NavLink to="/parties">{data[this.state.language].parties}</NavLink></li>
          <li className={this.state.activeIndex===3 ? 'active': null}  onClick={this.handleClick.bind(this, 3)} id="params"><NavLink to="/parametres">{data[this.state.language].params}</NavLink></li>

        </ul>
      </div>
  </div>		
</div>

		);
	}	
}

export default Menu;