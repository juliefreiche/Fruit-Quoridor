import React, { Component } from 'react';
import './main.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';

import { Provider } from 'react-redux';
import { createStore } from 'redux';

import {setSocket, updateGame} from '../../actions/actions';
import globalReducer from '../../reducers/index';

import Menu from '../menu/menu.js';
import Contacts from '../contacts/contacts.js';
import Parties from '../parties/parties.js';
import Parametres from '../parametres/parametres.js';
import Jeu from '../jeu/jeu.js';
import Profil from '../profil/profil.js';
import Top from '../top/top.js';
import Content from '../content/content.js';
import io from 'socket.io-client';

import {Route, NavLink, HashRouter} from "react-router-dom";

const masocket = io('http://localhost:1337');
const store = createStore(globalReducer);

class Main extends Component {

constructor(props) {
  super();
  var type_partie=""; // type de la partie qui va être jouée
  var uuid=""; // id de la partie qui va être joué
  var socket={
                "type_partie": type_partie,
                "uuid" : uuid,
                "masocket" : masocket
                };
  var shot = {
        "couleurJoueurCourant":'red',
        "couleurJoueurAdverse":'green',
        "idJoueurAdverse":'VERT',
        "idJoueurCourant":'ORANGE',
        "JoueurCourant":"40",
        "JoueurAdverse":"48",
        "listeMurs": [],
        "mursRestantsOrange": "10",
        "mursRestantsVert": "10"
        };
  store.dispatch(setSocket(socket));
  store.dispatch(updateGame(shot));
}

render(){
	return(
<Provider store={store} >
<HashRouter>
		<div>
			<Top/>
			<Menu/>
			<Content/>
			<Contacts/>

</div>
</HashRouter>
</Provider>
		);
	}	
}

export default Main;