import React, { Component } from 'react';
import './top.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import logo from './logo.png';
import { connect } from 'react-redux'
import { setLanguage } from '../../actions/actions.js'



class Top extends Component {

	constructor(props) {
    	super(props)
    	this.handleClick = this.handleClick.bind(this);

    	this.state = {
     	 activeIndex: 0,
      	 language: 0
    	}
	}

	handleClick(index, e) {
		this.setState({ activeIndex: index });
		dispatch(setLanguage(1));
    
   }

render(){
	return(
		<div >
		<div className="navbar">
		 <div className="container-fluid">

		<img src={logo} className="App-logo" alt="Logo Fruit-Quorridor"/>

		 

		 <button className="btn login-button">
             Connexion
		</button>

		<ul className="nav navbar-nav nav-language">
              <li className={this.state.activeIndex==0 ? 'active': null}  onClick={this.handleClick.bind(this, 0)}><a href="#" data-target="#" >EN</a></li>
              <li className={this.state.activeIndex==1 ? 'active': null}  onClick={this.handleClick.bind(this, 1)}><a href="#" data-target="#" >FR</a></li>
		</ul>

</div>
		</div>

</div>
		);
	}	
}

export default connect()(Top);