import React, { Component } from 'react';
import './main.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';

import Menu from '../menu/menu.js';
import Contacts from '../contacts/contacts.js';
import Parties from '../parties/parties.js';
import Parametres from '../parametres/parametres.js';
import Jeu from '../jeu/jeu.js';
import Profil from '../profil/profil.js';
import Top from '../top/top.js';
import Content from '../content/content.js';

import {
  Route,
  NavLink,
  HashRouter
} from "react-router-dom";

/*
import { createStore } from 'redux'
import todoApp from '../../reducers/reducerTest.js'
import language from '../../reducers/language.js'


import {
  addTodo,
  toggleTodo,
  setVisibilityFilter,
  VisibilityFilters
} from '../../actions/actionTest.js'

import { setLanguage } from '../../actions/actions.js'

let store = createStore(language)

// Log the initial state
console.log(store.getState())

const unsubscribe = store.subscribe(() =>
  console.log(store.getState())
)

// Dispatch some actions

store.dispatch(setLanguage(1))
//store.dispatch(setLanguage(1))




// Log the initial state
console.log(store.getState())

// Every time the state changes, log it
// Note that subscribe() returns a function for unregistering the listener
const unsubscribe = store.subscribe(() =>
  console.log(store.getState())
)

// Dispatch some actions
store.dispatch(addTodo('Learn about actions'))
store.dispatch(addTodo('Learn about reducers'))
store.dispatch(addTodo('Learn about store'))
store.dispatch(toggleTodo(0))
store.dispatch(toggleTodo(1))
store.dispatch(setVisibilityFilter(VisibilityFilters.SHOW_COMPLETED))

// Stop listening to state updates
unsubscribe()
*/

class Main extends Component {

render(){
	return(
<HashRouter>
		<div>
			<Top/>
			<Menu/>
			<Content/>
			<Contacts/>

</div>
</HashRouter>
		);
	}	
}

export default Main;