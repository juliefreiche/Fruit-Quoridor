import React, { Component } from 'react';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import { Stage, Layer, Rect, Image, Text, Circle} from 'react-konva';


import grille from './grilleJPG.jpg';

class Plateau extends Component {

 constructor(props) {
    super(props);
    this.state = {
    	wallLeft:10,
    	image:null,
    	
    tablePixelLignes: [36,84,131,178,225,272,320,367,414,462],
    epaisseurMur: 10,
    longueurMur:95,

    xInitVert:700,
    yInitVert:200,
    xInitHor:550,
    yInitHor:200,

    xInitJoueurCourant:250,
    yInitJoueurCourant:60,
    couleurJoueurCourant:'red',
    idJoueurCourant:'j1',
    xInitJoueurAdverse:250,
    yInitJoueurAdverse:440,
    couleurJoueurAdverse:'green',
    idJoueurAdverse:'j2'


    }

   
}



  componentDidMount() {
   var state=this.state;
   var gridSize=9;
   var horBarre= this.refs.horBarre;
   var vertBarre= this.refs.vertBarre;
   var joueurCourant= this.refs.joueurCourant;
   const layer=this.refs.myLayer;
   console.log(this.refs.test);
    const image = new window.Image();
    image.src = "http://www.iggamecenter.com/images/info/taiji/2.png";
    
    image.onload = () => {
      // setState will redraw layer
      // because "image" property is changed
      this.setState({
        image: image

  	});

      this.refs.joueurCourant.on('dragstart', function() {
    	vertBarre.position({
                            x : state.xInitVert,
                            y : state.yInitVert
                        });
    	horBarre.position({
                            x : state.xInitHor,
                            y : state.yInitHor
                        });
    	layer.draw();
    
    });

    this.refs.joueurCourant.on('dragend', function(){
    	let  newPosX, newPosY;
    	 if(this.attrs.x<state.tablePixelLignes[0]
        	||this.attrs.x>state.tablePixelLignes[9]
        	||this.attrs.y<state.tablePixelLignes[0]
        	||this.attrs.y>state.tablePixelLignes[9]){
        		newPosX=state.xInitJoueurCourant;
        		newPosY= state.yInitJoueurCourant; 

        }
        else{
    	for(var i=0;i<9;i++){
        		if(state.tablePixelLignes[i]<this.attrs.x&&state.tablePixelLignes[i+1]>this.attrs.x){
        			newPosX=(state.tablePixelLignes[i]+state.tablePixelLignes[i+1])/2;
        		}
        		if(state.tablePixelLignes[i]<this.attrs.y&&state.tablePixelLignes[i+1]>this.attrs.y){
        			newPosY=(state.tablePixelLignes[i]+state.tablePixelLignes[i+1])/2;
        		}
        	}
        }
        this.position({
                            x : newPosX,
                            y : newPosY
                        });
        layer.draw();

    });

    this.refs.horBarre.on('dragstart', function() {
    	vertBarre.position({
                            x : state.xInitVert,
                            y : state.yInitVert
                        });
    	joueurCourant.position({
                            x : state.xInitJoueurCourant,
                            y : state.yInitJoueurCourant
                        });

    	layer.draw();
    
    });
     this.refs.vertBarre.on('dragstart', function() {
     	horBarre.position({
                            x : state.xInitHor,
                            y : state.yInitHor
                        });
     	joueurCourant.position({
                            x : state.xInitJoueurCourant,
                            y : state.yInitJoueurCourant
                        });
    		layer.draw();
    });
    this.refs.horBarre.on('dragend', function() {
    	let  newPosX, newPosY;
        if(this.attrs.x<state.tablePixelLignes[0]-state.epaisseurMur
        	||this.attrs.x>state.tablePixelLignes[7]+state.epaisseurMur
        	||this.attrs.y<state.tablePixelLignes[1]-state.epaisseurMur
        	||this.attrs.y>state.tablePixelLignes[8]){
        	newPosX=state.xInitHor;
        newPosY= state.yInitHor;

        	        
        }
        else{
        	for(var i=0;i<10;i++){
        		if(Math.abs(state.tablePixelLignes[i]-this.attrs.x)<24){
        			newPosX=state.tablePixelLignes[i];
        		}
        		if(Math.abs(state.tablePixelLignes[i]-this.attrs.y)<24){
        			newPosY=state.tablePixelLignes[i];
        		}
        	}
        }

        this.position({
                            x : newPosX,
                            y : newPosY
                        });


        layer.draw();
    });

        this.refs.vertBarre.on('dragend', function() {
    	let  newPosX, newPosY;
        if(this.attrs.y<state.tablePixelLignes[0]-state.epaisseurMur
        	||this.attrs.y>state.tablePixelLignes[7]+state.epaisseurMur
        	||this.attrs.x<state.tablePixelLignes[1]-state.epaisseurMur
        	||this.attrs.x>state.tablePixelLignes[8]){
        	newPosX=state.xInitVert;
        	newPosY= state.yInitVert;


        	        
        }
        else{
        	for(var i=0;i<10;i++){
        		if(Math.abs(state.tablePixelLignes[i]-this.attrs.x)<24){
        			newPosX=state.tablePixelLignes[i];
        		}
        		if(Math.abs(state.tablePixelLignes[i]-this.attrs.y)<24){
        			newPosY=state.tablePixelLignes[i];
        		}
        	}
        }

        this.position({
                            x : newPosX,
                            y : newPosY
                        });


        layer.draw();
    });
    
  }
}
 


render(){


	return(

	<div className="center-block"> 
		<button id="valider" type="button" className="btn btn-success " >VALIDER MON TOUR</button>
		<Stage width={800} height={600} >
			<Layer ref="myLayer">
			<Image width={500} height={500} image={this.state.image}/>
			<Circle x={250} y={60} radius={15}   stroke='black' />
			<Circle x={250} y={440} radius={15}   stroke='black' />
			<Circle id={this.state.idJoueurCourant} ref="joueurCourant" x={this.state.xInitJoueurCourant} y={this.state.yInitJoueurCourant} radius={15} fill= {this.state.couleurJoueurCourant}  stroke='black' draggable={true} />
			<Circle id={this.state.idJoueurAdverse} ref="joueurAdverse" x={this.state.xInitJoueurAdverse} y={this.state.yInitJoueurAdverse} radius={15} fill= {this.state.couleurJoueurAdverse}  stroke='black' draggable={false} />
			
			<Text fontSize={30} fill='blue' x={550} y={100} text={this.state.wallLeft}/>
			
			<Rect ref="vertBarre" x={this.state.xInitVert} y={this.state.yInitVert} width={this.state.epaisseurMur} height={this.state.longueurMur} fill= 'brown' draggable='true'/>
			<Rect ref="horBarre"  x={this.state.xInitHor} y={this.state.yInitHor} width={this.state.longueurMur} height={this.state.epaisseurMur} fill= 'brown' draggable='true'/>
			</Layer>
		</Stage>



	</div>
		);


	


	}	
}
export default Plateau;