import React, { Component } from 'react';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';

import { Stage, Layer, Rect, Image, Line} from 'react-konva';
import grille from './grille9x9.png';

class Plateau extends Component {

 constructor(props) {
    super(props);

    this.state = {
      plateauPions: [
        [0,0,0,0,1,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0],
        [0,0,0,0,1,0,0,0,0],
      ]
      plateauMurs: [
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
        [0,0,0,0,0,0,0,0,0,0],
		[0,0,0,0,0,0,0,0,0,0],
      ]
    }
}

  componentDidMount() {
   var gridSize=9;

  }
 


render(){


	return(

	<div className="center-block"> 

	{this.state.plateauPions[8][8]}



	</div>
		);


	


	}	
}
export default Plateau;