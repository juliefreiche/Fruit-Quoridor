import React, { Component } from 'react';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';

import { Stage, Layer, Rect, Image, Line} from 'react-konva';
import grille from './grille9x9.png';

class Canvas extends Component {


 


render(){

	

	return(
	<div className="center-block"> 

		<Stage width={800} height={400}>
		<Layer>
		<Rect x='200' width="100" height="50" fill="yellow" draggable="false"/>
			<Line  points='[73, 70, 340, 23, 450, 60, 500, 20]'  stroke= 'black'/>
			<Rect  width="50" height="50" fill="red" draggable="false"/>
			<Image src={grille} />
			</Layer>
		</Stage>

	</div>
		);
	}	
}

export default Canvas;