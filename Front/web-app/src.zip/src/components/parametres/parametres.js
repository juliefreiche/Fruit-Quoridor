import React, { Component } from 'react';
import './parametres.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';



class Parametres extends Component {

render(){
	return(
		<div className='span8 main'>
		Parametres

</div>
		);
	}	
}

export default Parametres;