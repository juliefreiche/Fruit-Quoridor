import React, { Component } from 'react';
import './jeu.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {
  Route,
  Link,
  HashRouter
} from "react-router-dom";



class Jeu extends Component {

	constructor(props) {
    super(props)
    this.handleClick = this.handleClick.bind(this);
    
}

  
  handleClick(e) {

  
  }


render(){
	return(
	<div className="center-block"> 
		<Link to='/jouer' type="button" className="btn btn-primary btn-home" onClick={this.handleClick}  id="jeuIA">JOUER EN LOCAL</Link>
		<button type="button" className="btn btn-primary btn-home">JOUER EN LIGNE</button>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE UN AMI</button>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE L'IA</button>
	</div>
		);
	}	
}

export default Jeu;