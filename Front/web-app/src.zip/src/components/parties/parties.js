import React, { Component } from 'react';
import './parties.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';



class Parties extends Component {

render(){
	return(
		<div className='span8 main'>
		Parties

		</div>
		);
	}	
}

export default Parties;