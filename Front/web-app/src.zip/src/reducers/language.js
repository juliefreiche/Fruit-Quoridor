import { combineReducers } from 'redux'

import { LANGUAGE } from '../actions/actions.js'

function todos(state = [], action) {
  switch (action.type) {

    case LANGUAGE:
      return action.index

    default:
      return state
  }
}

const language = combineReducers({
  todos
})

export default language