export const LANGUAGE={
  type: LANGUAGE,
  index: 1
}


/*
 * action creators
 */

export function setLanguage(index) {
  return { type: LANGUAGE, index }
}

