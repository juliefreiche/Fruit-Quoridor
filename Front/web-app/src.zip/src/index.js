import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Main from './components/main/Main.js';
import registerServiceWorker from './registerServiceWorker';
import { Provider } from 'react-redux'
import { createStore } from 'redux'
import language from './reducers/language.js'

let store=createStore(language);

ReactDOM.render(
	<Provider store={store}>
		<Main />
	</Provider>,
document.getElementById('root')
);
registerServiceWorker();
