import React, { Component } from 'react';
import './content.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';

import Parties from '../parties/parties.js';
import Parametres from '../parametres/parametres.js';
import Jeu from '../jeu/jeu.js';
import Profil from '../profil/profil.js';
import Plateau from '../plateau/plateau.js';
import Login from '../login/login.js';
import Register from '../register/register.js'
import {
  Route
} from "react-router-dom";

class Content extends Component {

constructor(props) {
    super(props)   
}

render(){
	return(
	      <div className="content col-md-8">
            <Route path="/parties" component={Parties}/>
            <Route path="/profil" component={Profil}/>
            <Route exact path="/" component={Jeu}/>
            <Route path="/parametres" component={Parametres}/>
            <Route path="/jouer" component={Plateau}/>
            <Route path="/login" component={Login}/>
            <Route path="/register" component={Register}/>

          </div>
		);
	}	
}

export default Content;