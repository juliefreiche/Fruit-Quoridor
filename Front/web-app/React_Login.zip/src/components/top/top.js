import React, { Component } from 'react';
import './top.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import logo from './logo.png';
import { connect } from 'react-redux'
import { setLanguage } from '../../actions/actions.js'
import {NavLink} from 'react-router-dom';
import {setUser} from '../../actions/actions';
import Login from '../login/login.js';




class Top extends Component {

	constructor(props) {
    	super(props)
    	this.handleClick = this.handleClick.bind(this);

    	this.state = {
     	 activeIndex: 0,
      	 language: 0,
      	 user:this.props.user
		}
	}

	handleClick(index, e) {
		this.setState({ activeIndex: index });
		//dispatch(setLanguage(1));
   }
componentDidUpdate(props){
	console.log('Update TOP');
	console.log(props);
	if(this.state.user.connected!=this.props.user.connected||this.state.user.name!=this.props.user.name){
		console.log('TEST RECEIVE PROPS !');
	}
}
componentWillReceiveProps(nextProps) {
	console.log('nextProps TOP : '+nextProps);
}

render(){
	return(
		<div >

		<img src={logo} className="App-logo" alt="Logo Fruit-Quorridor"/>
		<div className="pull-right"><Login/></div>
		

		
</div>
		);
	}	
}
const mapStateToProps = (state, ownProps) => {
    return {
        user: state.userReducer.user
 } 
};

export default connect(mapStateToProps)(Top);
