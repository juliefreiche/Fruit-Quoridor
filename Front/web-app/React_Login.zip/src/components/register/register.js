import React, { Component } from 'react';
import './register.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {connect} from 'react-redux';
import {setSocket} from '../../actions/actions';


class Register extends Component {
	constructor(props) {
        super(props);

        this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);

		    this.state = { 
			username: '',
			password: '', 
			email:'',
			passwordVerif:''
		}; 
    }

	componentDidMount(){
		this.props.socket.masocket.on('successRegister', function(data){
			
			if(data==true){
				console.log('Success Register !!');
			}
			else{
				console.log('Erreur Register');
			}

			

		});
	}

	handleChange(key) {
	
	return function (e) {
      var state = {};
      state[key] = e.target.value;
      this.setState(state);
     }.bind(this);
  }
  handleSubmit(event){
  	event.preventDefault();

  	var userReg={username:this.state.username, email:this.state.email, password:this.state.password,passwordVerif:this.state.passwordVerif};
	
	this.props.socket.masocket.emit('register',userReg);
	//this.props.dispatch(setSocket(this.props.socket));
	
  }

render(){
	return(
		<div className='span8 main'>
		<h1>Register</h1>
		<form onSubmit={this.handleSubmit}  >
					<div className="form-group">
					<input type="email" name="email" placeholder="Email" value={this.state.email} 
                onChange={this.handleChange('email')}/>
			</div>
			<div className="form-group">

				<input type="text" name="username" placeholder="Username"  value={this.state.username} 
                onChange={this.handleChange('username')}/>
					 </div >

			<div className="form-group">
					<input type="password" name="password" placeholder="Password" value={this.state.password} 
                onChange={this.handleChange('password')}/>
			</div>
						<div className="form-group">
					<input type="password" name="password" placeholder="Password" value={this.state.passwordVerif} 
                onChange={this.handleChange('passwordVerif')}/>
			</div>



			<input type="submit" name="register" value="Register"/>

	</form>
	</div>
		);
	}	
}

const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket
 } 
};

export default connect(mapStateToProps)(Register);
