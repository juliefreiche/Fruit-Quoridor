import React, { Component } from 'react';
import './profil.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {NavLink} from 'react-router-dom';
import {connect} from 'react-redux';

import {setUser} from '../../actions/actions';
//import photoProfil from './defaultProfil.png'; //pb


class Profil extends Component {

	constructor(props) {
        super(props);
		
		this.state = { 
			username: this.props.user.name,
			email: this.props.user.email,
			connected:this.props.user.connected
		};
		 }

render(){
	return(
		<div className='span8 main'>
			<h1>Profil</h1>
			{ this.state.connected ?
			<div>
			<div> Nom : {this.state.username}</div>
			<div> Email : {this.state.email}</div>
			<div> Nombre de Victoire : </div>
			<div> Plus de statistique .... </div>
			</div>
			: <div>Connectez vous pour voir votre profil</div>}

		</div>
		
		);
	}	
}

const mapStateToProps = (state, ownProps) => {
    return {
        user: state.userReducer.user
 } 
};

export default connect(mapStateToProps)(Profil);