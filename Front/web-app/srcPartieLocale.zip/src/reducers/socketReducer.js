const socketReducer= (state={socket:{}},action) => { 
	console.log(action);
	switch (action.type) {
		case 'UPDATE_SOCKET':
			const newState1={socket:action.obj}; 
			return newState1;
	default: 
		return state;
	}
}
export default socketReducer;