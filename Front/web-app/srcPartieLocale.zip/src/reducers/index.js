import { combineReducers } from 'redux';
import shotReducer from './shotReducer';
import socketReducer from './socketReducer';

const globalReducer = combineReducers({
  socketReducer: socketReducer,
  shotReducer: shotReducer
});

export default globalReducer;