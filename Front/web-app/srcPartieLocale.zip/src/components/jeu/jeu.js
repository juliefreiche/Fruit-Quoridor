import React, { Component } from 'react';
import './jeu.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {connect} from 'react-redux';
import {setSocket, updateGame} from '../../actions/actions';
import {Route, Link, HashRouter} from "react-router-dom";

class Jeu extends Component {

	constructor(props) {
    super(props)
    this.create_local_game = this.create_local_game.bind(this);
    this.create_socket = this.create_socket.bind(this);
    this.convertList = this.convertList.bind(this);
    this.create_socket();
}

  create_socket(){
  console.log(this.props.socket.masocket);
  var master = this;
  this.props.socket.masocket.on('connection', function (socket) {
      

      console.log(master.props.socket);
      master.props.socket.masocket.emit('data_comm',socket);
      
      master.props.socket.masocket.on('local_game',function(data){
        console.log("local game : " + data);
        master.props.socket.uuid=data;
        console.log(master.props.socket);
        master.props.dispatch(setSocket(master.props.socket));

      });

      master.props.socket.masocket.on('erreur',function(data){

        console.log("erreur : " + data);
        master.props.dispatch(updateGame(master.props.shot));
        alert(data);

      });

      master.props.socket.masocket.on('move_ok',function(data){

        console.log("mouvement accepté : ");
        console.log(data);
        if(data.jsonPlateau.joueurCourant=="VERT"){
        	master.props.shot.couleurJoueurCourant = 'green'; 
        	master.props.shot.idJoueurCourant = 'VERT'; 
        	master.props.shot.couleurJoueurAdverse = 'red'; 
        	master.props.shot.idJoueurAdverse = 'ORANGE';
        	master.props.shot.JoueurCourant = data.jsonPlateau.joueurVert;
        	master.props.shot.JoueurAdverse = data.jsonPlateau.joueurOrange;
        }
        else if(data.jsonPlateau.joueurCourant=="ORANGE"){
        	master.props.shot.couleurJoueurCourant = 'red'; 
        	master.props.shot.idJoueurCourant = 'ORANGE'; 
        	master.props.shot.couleurJoueurAdverse = 'green'; 
        	master.props.shot.idJoueurAdverse = 'VERT';
        	master.props.shot.JoueurCourant = data.jsonPlateau.joueurOrange;
        	master.props.shot.JoueurAdverse = data.jsonPlateau.joueurVert;
        }
        else
        	console.log("erreur de joueurCourant");

        console.log(master.props.shot);
        master.props.shot.mursRestantsOrange = data.jsonPlateau.mursRestantsOrange;
        master.props.shot.mursRestantsVert = data.jsonPlateau.mursRestantsVert;
        master.props.shot.listeMurs = master.convertList(data.jsonPlateau.murs);
        master.props.dispatch(updateGame(master.props.shot));
      });
      

    });
  }

create_local_game() {

this.props.socket.type_partie = "local";
console.log(this.props.socket.type_partie);
this.props.socket.masocket.emit('create_game',this.props.socket.type_partie);
this.props.dispatch(setSocket(this.props.socket));
}

convertList(maListe){
  var listString=Array(maListe.length);
  for(let i=0;i<maListe.length;i++)
    listString[i]=maListe[i].toString();
  return listString;

}


render(){
	return(
	<div className="center-block"> 
		<Link to='/jouer' type="button" className="btn btn-primary btn-home" onClick={this.create_local_game}  id="jeuIA">JOUER EN LOCAL</Link>
		<button type="button" className="btn btn-primary btn-home">JOUER EN LIGNE</button>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE UN AMI</button>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE L'IA</button>
	</div>
		);
	}	
}
const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket,
        shot: state.shotReducer.shot
 } 
};

export default connect(mapStateToProps)(Jeu);
