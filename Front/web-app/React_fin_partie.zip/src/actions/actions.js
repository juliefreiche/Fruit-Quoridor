export const setSocket=(socket)=>{ 
	return {
		type: 'UPDATE_SOCKET',
		obj:socket
	};
}

export const updateGame=(game)=>{ 
	return {
		type: 'UPDATE_GAME',
		obj:game
	};
}

