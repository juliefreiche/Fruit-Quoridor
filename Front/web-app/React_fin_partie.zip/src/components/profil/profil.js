import React, { Component } from 'react';
import './profil.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
//import photoProfil from './defaultProfil.png'; //pb


class Profil extends Component {

render(){
	return(
		<div className='span8 main'>
			<h1>Profil</h1>
			<div> Nom </div>
			<div> Nombre de Victoire : </div>
			<div> Plus de statistique .... </div>

		</div>
		
		);
	}	
}

export default Profil;