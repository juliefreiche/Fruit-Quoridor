import React, { Component } from 'react';
import './jeu.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {connect} from 'react-redux';
import {setSocket, updateGame} from '../../actions/actions';
import {Route, Link, HashRouter} from "react-router-dom";

class Jeu extends Component {

	constructor(props) {
    super(props)
    this.create_game = this.create_game.bind(this);
    this.create_socket = this.create_socket.bind(this);
    this.create_socket();
}

  create_socket(){
  console.log(this.props.socket.masocket);
  var master = this;
  this.props.socket.masocket.on('connection', function (socket) {
      

      console.log(master.props.socket);
      //master.props.socket.masocket.emit('data_comm',socket);
      
      master.props.socket.masocket.on('local_game',function(data){
        console.log("local game : " + data);
        master.props.socket.uuid=data;
        console.log(master.props.socket);
        master.props.socket.debutJeu = true; 
        master.props.dispatch(setSocket(master.props.socket));

      });

      master.props.socket.masocket.on('online_game',function(data){
        console.log("online game : ");
        console.log(data);
        master.props.socket.debutJeu = true; 
        master.props.socket.online_game.id = data.id;
        master.props.socket.online_game.joueur = data.joueur;
        master.props.dispatch(setSocket(master.props.socket));

    });
    });
  }

create_game(type) {
this.props.socket.type_partie = type;  
this.props.socket.masocket.emit('create_game',type);
console.log(type);
this.props.dispatch(setSocket(this.props.socket));
}


render(){
	return(
	<div className="center-block"> 
		<Link to='/jouer' type="button" className="btn btn-primary btn-home" onClick={this.create_game.bind(this,'local')} >JOUER EN LOCAL</Link>
		<Link to='/jouer' type="button" className="btn btn-primary btn-home" onClick={this.create_game.bind(this,'online')} >JOUER EN LIGNE</Link>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE UN AMI</button>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE L'IA</button>
	</div>
		);
	}	
}
const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket,
        shot: state.shotReducer.shot
 } 
};

export default connect(mapStateToProps)(Jeu);
