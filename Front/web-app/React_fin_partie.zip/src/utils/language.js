const language = [
//English
{
	'jouer': 'Play',
	'profil': 'My Profile',
	'params': 'Parameters',
	'parties': "My Games",
},

//French
{
	'jouer': 'Jouer',
	'profil': 'Mon Profil',
	'params': 'Mes Paramètres',
	'parties': 'Mes Parties',
}


] export default language;