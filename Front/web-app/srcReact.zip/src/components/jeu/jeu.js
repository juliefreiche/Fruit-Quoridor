import React, { Component } from 'react';
import './jeu.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {connect} from 'react-redux';
import {setSocket, updateGame} from '../../actions/actions';
import {Route, Link, HashRouter} from "react-router-dom";

class Jeu extends Component {

	constructor(props) {
    super(props)
    this.create_local_game = this.create_local_game.bind(this);
    this.create_socket = this.create_socket.bind(this);
    this.create_socket();
}

  create_socket(){
  console.log(this.props.socket.masocket);
  var master = this;
  this.props.socket.masocket.on('connection', function (socket) {
      console.log(master.props.socket);
      master.props.socket.masocket.emit('data_comm',socket);
      
      master.props.socket.masocket.on('local_game',function(data){
        console.log("local game : " + data);
        master.props.socket.uuid=data;
        console.log(master.props.socket);
        master.props.dispatch(setSocket(master.props.socket));

      });

      master.props.socket.masocket.on('erreur',function(data){

        console.log("erreur : " + data);
        alert(data);

      });

      master.props.socket.masocket.on('move_ok',function(data){

        console.log("mouvement accepté : ");
        console.log(data);
        //changer id joueur courant
        // si string.lenght = 4 ajouter le mur dans la liste
        // si string.lenght = 2 deplacer pion
      });
      

    });
  }

create_local_game() {

this.props.socket.type_partie = "local";
console.log(this.props.socket.type_partie);
this.props.socket.masocket.emit('create_game',this.props.socket.type_partie);
this.props.dispatch(setSocket(this.props.socket));
}



render(){
	return(
	<div className="center-block"> 
		<Link to='/jouer' type="button" className="btn btn-primary btn-home" onClick={this.create_local_game}  id="jeuIA">JOUER EN LOCAL</Link>
		<button type="button" className="btn btn-primary btn-home">JOUER EN LIGNE</button>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE UN AMI</button>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE L'IA</button>
	</div>
		);
	}	
}
const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket,
        game: state.gameReducer.game
 } 
};

export default connect(mapStateToProps)(Jeu);
