const gameReducer= (state={game:{}},action) => { 
	console.log(action);
	switch (action.type) {
		case 'UPDATE_GAME':
			const newState1={game:action.obj}; 
			return newState1;
	default: 
		return state;
	}
}
export default gameReducer;