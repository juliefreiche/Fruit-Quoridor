import { combineReducers } from 'redux';
import gameReducer from './gameReducer';
import socketReducer from './socketReducer';

const globalReducer = combineReducers({
  socketReducer: socketReducer,
  gameReducer: gameReducer
});

export default globalReducer;