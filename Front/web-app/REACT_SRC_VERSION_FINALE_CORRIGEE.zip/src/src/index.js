import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Main from './components/main/Main.js';

ReactDOM.render(<Main />, document.getElementById('root'));
