import React, { Component } from 'react';
import './jeu.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {connect} from 'react-redux';
import {setSocket, updateGame} from '../../actions/actions';
import {Route, Link, HashRouter} from "react-router-dom";

class Jeu extends Component {

	constructor(props) {
    super(props)
    this.create_game = this.create_game.bind(this);
    this.create_socket = this.create_socket.bind(this);
    this.create_socket();
}

  create_socket(){
  console.log(this.props.socket.masocket);
  var master = this;
  this.props.socket.masocket.on('connection', function (socket) {
      

      console.log(master.props.socket);
      //master.props.socket.masocket.emit('data_comm',socket);
      
      master.props.socket.masocket.on('local_game',function(data){
        console.log("local game : " + data);
        master.props.socket.uuid=data;
        console.log(master.props.socket);
        master.props.socket.debutJeu = true; 
        master.props.dispatch(setSocket(master.props.socket));

      });

      master.props.socket.masocket.on('online_game',function(data){
        console.log("online game : ");
        console.log(data);
        master.props.socket.debutJeu = true; 
        master.props.socket.online_game.id = data.id;
        master.props.socket.online_game.joueur = data.joueur;
        master.props.socket.online_game.adversaire = data.adversaire;
        master.props.dispatch(setSocket(master.props.socket));

    });
    });
  }

create_game(type) {
this.props.socket.type_partie = type;  
this.props.socket.masocket.emit('create_game',type);
console.log(type);
this.props.dispatch(setSocket(this.props.socket));
}
    //<Link to='/jouer' type="button" className="btn btn-primary btn-home" onClick={this.create_game.bind(this,'local')} >JOUER EN LOCAL</Link>
    //<Link className="btn btn-primary btn-home"  to='/jouer' type="button" onClick={this.create_game.bind(this,'online')} >JOUER EN LIGNE</Link>
    

render(){
	return(
	<div className="center-block"> 

    {!this.props.user.connected ? <div> Connectez vous pour jouer en ligne ! </div>:null}
		<Link to='/jouer' type="button" className="btn btn-primary btn-home" onClick={this.create_game.bind(this,'local')} >JOUER EN LOCAL</Link>
		<div className={!this.props.user.connected ? "hidden":null}><Link className="btn btn-primary btn-home"  to='/jouer' type="button" onClick={this.create_game.bind(this,'online')} >JOUER EN LIGNE</Link></div>
		<button type="button" className="btn btn-primary btn-home" >JOUER CONTRE L'IA</button>
	</div>
		);
	}	
}
const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket,
        shot: state.shotReducer.shot,
        user: state.userReducer.user

 } 
};

export default connect(mapStateToProps)(Jeu);
