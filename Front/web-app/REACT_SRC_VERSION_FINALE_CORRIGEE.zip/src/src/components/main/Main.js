import React, { Component } from 'react';
import './main.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';

import { Provider } from 'react-redux';
import { createStore } from 'redux';

import {setSocket, updateGame} from '../../actions/actions';
import globalReducer from '../../reducers/index';

import Menu from '../menu/menu.js';
import Top from '../top/top.js';
import Content from '../content/content.js';
import io from 'socket.io-client';

import {HashRouter} from "react-router-dom";

const masocket = io('http://localhost:1337');
const store = createStore(globalReducer);

class Main extends Component {

constructor(props) {
  super();
  var type_partie=""; // type de la partie qui va être jouée
  var uuid=""; // id de la partie qui va être joué
  var online_game = {
    "id": "",
    "joueur":""
  };
  var socket={
                "online_game": online_game,
                "type_partie": type_partie,
                "uuid" : uuid,
                "masocket" : masocket,
                "debutJeu" : false
                };
  var shot = {
        "imageJoueurCourant":"http://localhost:1337/fraise.png",
        "imageJoueurAdverse":"http://localhost:1337/poire.png",
        "idJoueurAdverse":"VERT",
        "idJoueurCourant":"ORANGE",
        "JoueurCourant":"40",
        "JoueurAdverse":"48",
        "listeMurs": [],
        "mursRestantsOrange": "10",
        "mursRestantsVert": "10",
        "messageTour": "C'est au tour du joueur:",
        "messageErreur": "C'est au tour du joueur ORANGE"
        };
  store.dispatch(setSocket(socket));
  store.dispatch(updateGame(shot));
}

render(){
	return(
<Provider store={store} >
<HashRouter>
		<div>
			<Top/>
			<Menu/>
			<Content/>
</div>
</HashRouter>
</Provider>
		);
	}	
}

export default Main;