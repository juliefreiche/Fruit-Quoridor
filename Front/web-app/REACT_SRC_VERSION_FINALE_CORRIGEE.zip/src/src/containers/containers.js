import * as components from '../components'
import { setLanguage } from '../actions/actions.js'
import { connect } from 'react-redux'

const mapStateToProps = (state) => {
    return {todos: state}
}

const mapDispatchToProps = (dispatch) => {
    return {
        language: index => dispatch(setLanguage(index))
    }
}

const TodoList = connect(mapStateToProps, mapDispatchToProps)(components.TodoList)

export default TodoList