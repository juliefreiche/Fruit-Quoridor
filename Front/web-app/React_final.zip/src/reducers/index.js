import { combineReducers } from 'redux';
import shotReducer from './shotReducer';
import socketReducer from './socketReducer';
import userReducer from './userReducer';


const globalReducer = combineReducers({
  socketReducer: socketReducer,
  shotReducer: shotReducer,
  userReducer: userReducer
});

export default globalReducer;