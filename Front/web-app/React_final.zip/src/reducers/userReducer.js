const userReducer= (state={user:{}},action) => { 
	console.log(action);
	switch (action.type) {
		case 'UPDATE_USER':
			const newState1={user:action.obj}; 
			return newState1;
	default: 
		return state;
	}
}
export default userReducer;