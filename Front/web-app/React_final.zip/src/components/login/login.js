/*global FB*/
import React, { Component } from 'react';
import './login.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {connect} from 'react-redux';
import {setSocket, setUser} from '../../actions/actions';
import {Link} from "react-router-dom";

class Login extends Component {
	
	constructor(props) {
        super(props);
        var master=this;
		
		this.state = { 
      email: this.props.user.email,
			username: this.props.user.name,
			password: '', 
			connected:this.props.user.connected,
			failAuth:false
		};
		 this.logout = this.logout.bind(this);
   		 this.loginWithFB=this.loginWithFB.bind(this);
    	 this.create_user=this.create_user.bind(this);
    	 //this.successAuth=this.successAuth.bind(this);
		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	
    }
	handleChange(key) {
	
		return function (e) {
      var state = {};
      state[key] = e.target.value;
      this.setState(state);
     }.bind(this);
  }

//cree User pour facebook et envoie à la socket la réponse de facebook
//PB emit OK Mais les listener n'ont pas l'ai de fonctionner
create_user() {
		var master=this;
        var props=this.props;
        FB.api('/me', function(response) {
        		
                console.log('Create user for : ' + response.name);
                
                props.socket.masocket.emit('login',response);
               
            });
    }
//
    logout(){
      var master=this;
       FB.getLoginStatus(function(response) {
     		 console.log(response);
     		 if (response.status === 'connected') {
     		 	FB.logout(function(response) {
        		// user is now logged out
        			console.log('Deconnexion fct');
       				console.log(response);
        			console.log('sending disconnect FB...');
              master.props.socket.masocket.emit('logout',master.props.user);
              
      				
               master.props.user.connected=false;
                master.props.user.name='';
                 master.props.user.email='';
                master.props.user.id='';
                master.props.dispatch(setUser(master.props.user));
                 master.setState({
                    username: '',
                    email:'',
                    password: '', 
                    connected:false
                });
     		  });
     		 }
     		 else{
     		 	master.props.socket.masocket.emit('logout',master.props.user);
                         master.props.user.connected=false;
                master.props.user.name='';
                master.props.user.id='';
                master.props.dispatch(setUser(master.props.user));
                 master.setState({
                    username: '',
                    password: '', 
                    connected:false
                });
     		 }
     	});

	}
    loginWithFB(){
      console.log('Log with FB...');
      FB.getLoginStatus(function(response) {
      console.log(response);
      this.statusChangeCallback(response);
    
      });
    }


componentDidMount(){
  console.log('didMount');
  var master=this;
  
      this.props.socket.masocket.on('disconnect',function(data){
        console.log('DECONNEXION SOCKET EVENT');    

        master.props.user.connected=false;
        master.props.user.email='';
            master.props.user.name='';
          master.props.user.id='';
          master.props.dispatch(setUser(master.props.user));
            master.setState({
              username: '',
          password: '', 
          connected:false
        });
    });
    


  this.props.socket.masocket.on('FBLogin',function(data){
				console.log('FB Login');
				master.setState({connected:true,username:data.username});
        	    console.log(master.state);
                master.props.user.name=data.username;
                console.log(master.props.user);
				master.props.dispatch(setUser(master.props.user));
                console.log('dipatch user');
		});
  		this.props.socket.masocket.on('successAuth',function(data){
				console.log('SUCCESS');
        console.log(data);
				master.setState({username:data.name,email:data.email, password:'',connected:data.connected, failAuth:!(data.connected)});
				master.props.user.name=data.name;
        master.props.user.connected=data.connected;
        master.props.user.email=data.email;           
                console.log(master.props.user);
                master.props.dispatch(setUser(master.props.user));
		});


  window.fbAsyncInit = function() {
    FB.init({
      appId      : '148400525821786',
      cookie     : true,
      xfbml      : true,
      status     : true,
      version    : 'v2.11'
    });
      console.log('Init');
       FB.AppEvents.logPageView();  
      
       // These three cases are handled in the callback function.
    FB.getLoginStatus(function(response) {
      console.log(response);
      this.statusChangeCallback(response);
    }.bind(this), true);

    FB.Event.subscribe('auth.authResponseChange',function(response){
    console.log('auth changed !');
    this.statusChangeCallback(response);
  }.bind(this));
    
  }.bind(this);

  


  
    (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.11&appId=148400525821786";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
    // FB.AppEvents.logPageView();  

  }

// This is called with the results from from FB.getLoginStatus().
statusChangeCallback(response) {
  console.log('statusChangeCallback');
  console.log(response);
  
  // The response object is returned with a status field that lets the
  // app know the current login status of the person.
  // Full docs on the response object can be found in the documentation
  // for FB.getLoginStatus().
  if (response.status === 'connected') {
    // Logged into your app and Facebook.
;    
    this.create_user();

  } else if (response.status === 'not_authorized') {
    // The person is logged into Facebook, but not your app.
    console.log('log into app');
    /*
    this.setState({connected:false});

    this.props.user.connected=false;
    this.props.dispatch(setUser(this.props.user));
    console.log('dipatch user');
    */

  } else {
    // The person is not logged into Facebook, so we're not sure if
    // they are logged into this app or not.
    console.log('log into fb');
    /*
    this.setState({connected:false});
    this.props.user.connected=false;
    this.props.dispatch(setUser(this.props.user));
    */
    console.log('dipatch user');
  }
};
  
  handleSubmit(event) {
  	var login={email:this.state.email, password:this.state.password};
	console.log('Login submitted :  ' + this.state.username +' : '+this.state.password);
	event.preventDefault();

	console.log(this.props.socket.masocket);
	this.props.socket.masocket.emit('login',login);
	this.props.dispatch(setSocket(this.props.socket));
	console.log('test send user');
}


	
  render() {
    return (
	
      <div className="Login">
		 <form onSubmit={this.handleSubmit}  >
		 {!this.state.connected ?	
 <div className="form-group">
				<input type="email" name="email" placeholder="Email"  value={this.state.email} 
                onChange={this.handleChange('email')}/>
					 </div > :null}	
					 {!this.state.connected?	
			<div className="form-group">
					<input type="password" name="password" placeholder="Password" value={this.state.password} 
                onChange={this.handleChange('password')}/>
			</div>
			:null}
			{!this.state.connected ?	
        <div>
			<input type="submit" name="login" className="login loginmodal-submit" value="Login"/>
</div>
			:null}
      <div className={ this.state.connected ? 'hidden':null}>
      <div  className="fb-login-button" data-auto-logout-link='true' data-max-rows="1" data-size="large" data-button-type="continue_with" data-show-faces="false" data-auto-logout-link="false" data-use-continue-as="false"></div>
      </div>

			</form>

			<div>
				        		{this.state.connected ?<div className="btn" onClick={this.logout.bind(this)}>Log out</div>:<div>   <Link to='/register' type="button" className="btn">Register</Link></div>}

        		{ this.state.connected ?  <div> Logged as {this.state.username}</div>: null }
        	</div>
          


			
		{ this.state.failAuth ? <div className="alert alert-danger" >Bad Authentication !</div> :null}
			

	</div>
	
    );
  }

}

const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket,
        user: state.userReducer.user
 } 
};

export default connect(mapStateToProps)(Login);
