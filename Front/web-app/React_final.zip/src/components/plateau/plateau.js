import React, { Component } from 'react';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import { Stage, Layer, Rect, Image, Text, Circle} from 'react-konva';
import {connect} from 'react-redux';
import {setSocket, updateGame} from '../../actions/actions';

class Plateau extends Component {

 constructor(props) {
    super(props);
    this.getCoordWallFromPixel = this.getCoordWallFromPixel.bind(this);
    this.getMouvement = this.getMouvement.bind(this);
    this.convertList = this.convertList.bind(this);
    this.send_coord=this.send_coord.bind(this);
    this.updateFunction = this.updateFunction.bind(this);
    var master = this;
    this.state = {
        varDrag: 0,
    	wallLeft:10,
    	image:new window.Image(),
        imagePoire:new window.Image(),
        imageFraise:new window.Image(),
        imageCourant:new window.Image(),
        imageAdverse:new window.Image(),
        imageOnline:new window.Image(),
        tablePixelLignes: [36,84,131,178,225,272,320,367,414,462],
        tablePixelPions: [46,94,141,188,235,282,330,377,424],
        adresse: "http://192.168.1.100:1337/",
        messageErreur:"",

        listeMursX: [],
        listeMursY: [],
        listeMursW: [],
        listeMursH: [],
        epaisseurMur: 10,
        longueurMur:95,

        xInitVert:700,
        yInitVert:200,
        xInitHor:550,
        yInitHor:200,
    }

   this.state.image.src = this.state.adresse + "damier.png";
   this.state.imageFraise.src = this.state.adresse + "fraise.png";
   this.state.imagePoire.src = this.state.adresse + "poire.png";
   console.log(this.props.socket.online_game.joueur);

    this.props.socket.masocket.on('move_ok',function(data){
        console.log("mouvement accepté : ");
        console.log(data);
        if(data.jsonPlateau.joueurCourant=="VERT"){ 
            master.props.shot.idJoueurCourant = 'VERT'; 
            master.props.shot.idJoueurAdverse = 'ORANGE';
            master.props.shot.JoueurCourant = data.jsonPlateau.joueurVert;
            master.props.shot.JoueurAdverse = data.jsonPlateau.joueurOrange;
            master.state.imageCourant = master.state.imagePoire;
            master.state.imageAdverse = master.state.imageFraise;
        }
        else if(data.jsonPlateau.joueurCourant=="ORANGE"){
            master.props.shot.idJoueurCourant = 'ORANGE'; 
            master.props.shot.idJoueurAdverse = 'VERT';
            master.props.shot.JoueurCourant = data.jsonPlateau.joueurOrange;
            master.props.shot.JoueurAdverse = data.jsonPlateau.joueurVert;
            master.state.imageCourant = master.state.imageFraise;
            master.state.imageAdverse = master.state.imagePoire;
        }
        else
            console.log("erreur de joueurCourant");

        if(master.props.socket.type_partie=="online"){
            if(data.jsonPlateau.joueurCourant==master.props.socket.online_game.joueur)
                master.props.shot.messageTour = "A toi de jouer";
            if(data.jsonPlateau.joueurCourant!=master.props.socket.online_game.joueur)
                master.props.shot.messageTour = "Attend ton tour";
        }

        console.log(master.props.shot);
        master.state.varDrag = 0;
        master.props.shot.mursRestantsOrange = data.jsonPlateau.mursRestantsOrange;
        master.props.shot.mursRestantsVert = data.jsonPlateau.mursRestantsVert;
        master.props.shot.listeMurs = master.convertList(data.jsonPlateau.murs);
        master.props.dispatch(updateGame(master.props.shot));
        if(data.fin_partie=="false")
        {
            master.updateFunction();
        }
        else{
            master.props.socket.debutJeu = false;
            console.log(master.props.shot);
            master.props.dispatch(setSocket(master.props.socket));
            master.props.dispatch(updateGame(master.props.shot));
            master.updateFunction();
            alert("Le joueur " + data.fin_partie + " a gagné");
        }

        });
    this.props.socket.masocket.on('erreur',function(data){
        console.log("erreur : " + data);
        master.state.messageErreur=data;
        master.state.varDrag = 0;
        master.props.dispatch(setSocket(master.props.socket));
        master.props.dispatch(updateGame(master.props.shot));
        master.updateFunction();
        });
   
}

send_coord(couleur) {
    console.log(this.props.socket.uuid);
    this.state.messageErreur="";
    if(this.props.socket.uuid!="")
    {

            var coord = this.getMouvement();
            var data={
                   "type_partie": this.props.socket.type_partie,
                    "coord" : coord,
                    "joueur" : couleur,
                    "id" : this.props.socket.uuid
                };
            this.props.socket.masocket.emit('move',data);
            console.log(this.props.shot);

    }
    else
        {
            console.log(this.props.socket.masocket);
            var coord = this.getMouvement();
            var data={
                        "coord" : coord,
                        "joueur" : couleur,
                        "id" : this.props.socket.online_game.id
                    };
            console.log(data);
            this.props.socket.masocket.emit('move',data);
        }

}

convertList(maListe){
  var listString=Array(maListe.length);

  for(let i=0;i<maListe.length;i++)
  {
    listString[i]=maListe[i].toString();
    if(listString[i].length == 3)
    {
      listString[i]= "0"+listString[i];
    }
  }
  return listString;

}

getMouvement(){
	var mouvement=this.getCoordWallFromPixel(this.refs.horBarre.attrs.x,this.refs.horBarre.attrs.y,'h');
	if(mouvement==-1){
		mouvement=this.getCoordWallFromPixel(this.refs.vertBarre.attrs.x,this.refs.vertBarre.attrs.y,'v');
	}
	if(mouvement==-1){
		mouvement=this.getCoordPieceFromPixel(this.refs.joueurCourant.attrs.x,this.refs.joueurCourant.attrs.y);
	}
    if(mouvement==-1){
        mouvement='99';
    }
	console.log(mouvement);
	return mouvement;
}

getCoordWallFromPixel(xPixel,yPixel,orientation){
	var table=this.state.tablePixelLignes;
	var xDebut,xFin,yDebut,yFin;
	var coordFinal=-1;
	var indic='';
	//console.log(xPixel+','+yPixel);
	for(let i=0;i<10;i++){
		if(xPixel==table[i]){
			indic=indic+'o';
			xDebut=i;
			if(orientation=='h'){
				xFin=xDebut+2;
				indic=indic+'o';
			}
			if(orientation=='v'){
				xFin=xDebut;
				indic=indic+'o';
			}
		}
		if(yPixel==table[i]){
			yFin=9-i;
			indic=indic+'o';
			
			if(orientation=='h'){
				yDebut=yFin;
				indic=indic+'o';
			}
			if(orientation=='v'){
				yDebut=yFin-2;
				indic=indic+'o';
			}
			
		}
	}
	if(indic=='oooo'){
		coordFinal=xDebut+''+yDebut+''+xFin+''+yFin;
	}
	return coordFinal;
}

getCoordPieceFromPixel(xPixel,yPixel){
	var table=this.state.tablePixelPions;
	var x,y;
	var coordFinal=-1;
	var indic='';
	console.log(xPixel+','+yPixel);
	
	for(let i=0;i<9;i++){
		if(xPixel==table[i]){
			x=i;
			indic=indic+'o';
		}
		if(yPixel==table[i]){
			y=8-i;
			indic=indic+'o';
		}
	}
	if(indic=='oo'){
		coordFinal=x+''+y;
	}
	console.log(coordFinal);
	return coordFinal;
}

getPixelWallFromCoord(coord){
	var x1=coord[0];
	var y1=coord[1];
	var x2=coord[2];
	var y2=coord[3];
	var position;
	var xPixel;
	var yPixel;
	if(coord.length!=4) return -1;
	xPixel=this.state.tablePixelLignes[x1];
	yPixel=this.state.tablePixelLignes[9-y2];
	
	position={x:xPixel,y:yPixel};
	return position;
}
getPixelPieceFromCoord(coord){
	var x=coord[0];
	var y=coord[1];
	var position;
	var xPixel;
	var yPixel;
	if(coord.length!=2) return -1;
	xPixel=this.state.tablePixelPions[x];
	yPixel=this.state.tablePixelPions[8-y];
	
	position={x:xPixel,y:yPixel};
	return position;
	
}

getOrientationWallFromCoord(coord){
	var x1=coord[0];
	var y1=coord[1];
	var x2=coord[2];
	var y2=coord[3];
	var orientation;

	if(coord.length!=4) return -1;

	if(x1<x2&&y1==y2) return 'h';
	if(y1<y2&&x1==x2) return 'v';
	return -1;
}
getDimensionWallFromOrientation(orientation){
	let dimension={width:0,height:0};
	if(orientation==='h'){
		dimension={
			width:this.state.longueurMur,
			height:this.state.epaisseurMur
		}
	}
	if(orientation==='v'){
		dimension={
			width:this.state.epaisseurMur,
			height:this.state.longueurMur
		}
	}
	return dimension;
}

  updateFunction(){
   var master=this;
   var state=this.state;
   var gridSize=9;
   var horBarre= this.refs.horBarre;
   var vertBarre= this.refs.vertBarre;
   var joueurCourant= this.refs.joueurCourant;
   var layer=this.refs.myLayer;
   var tableMursX=new Array(20);
   var tableMursY=new Array(20);

   var tableMursW = new Array(20);
   var tableMursH = new Array(20);


    for(let i=0;i<this.props.shot.listeMurs.length;i++){
            let coord=master.getPixelWallFromCoord(this.props.shot.listeMurs[i]);
            let dimension=master.getDimensionWallFromOrientation(master.getOrientationWallFromCoord(this.props.shot.listeMurs[i]));
    
            tableMursX[i]=coord.x;
            tableMursY[i]=coord.y;
            tableMursH[i]=dimension.height;
            tableMursW[i]=dimension.width;  
        }
     this.setState({listeMursX:tableMursX,listeMursY:tableMursY,listeMursW:tableMursW,listeMursH:tableMursH});

    this.refs.joueurCourant.on('dragstart', function() {
        vertBarre.position({
                            x : state.xInitVert,
                            y : state.yInitVert
                        });
        horBarre.position({
                            x : state.xInitHor,
                            y : state.yInitHor
                        });
    
    });

    this.refs.joueurCourant.on('dragend', function(){
        let  newPosX, newPosY;
         if(this.attrs.x<state.tablePixelLignes[0]
            ||this.attrs.x>state.tablePixelLignes[9]
            ||this.attrs.y<state.tablePixelLignes[0]
            ||this.attrs.y>state.tablePixelLignes[9]){
                newPosX = master.getPixelPieceFromCoord(master.props.shot.JoueurCourant).x;
                newPosY = master.getPixelPieceFromCoord(master.props.shot.JoueurCourant).y; 

        }
        else{
        for(var i=0;i<9;i++){
                if(state.tablePixelLignes[i]<this.attrs.x&&state.tablePixelLignes[i+1]>this.attrs.x){
                    newPosX=state.tablePixelPions[i];
                }
                if(state.tablePixelLignes[i]<this.attrs.y&&state.tablePixelLignes[i+1]>this.attrs.y){
                    newPosY=state.tablePixelPions[i];;
                }
            }
        }
        this.position({
                            x : newPosX,
                            y : newPosY
                        });
        layer.draw();
        if(master.state.varDrag < 1){
            master.send_coord(master.props.shot.idJoueurCourant);
        }
        master.state.varDrag = 1;

    });

    this.refs.horBarre.on('dragstart', function() {
        vertBarre.position({
                            x : state.xInitVert,
                            y : state.yInitVert
                        });
        joueurCourant.position({
                            x : master.getPixelPieceFromCoord(master.props.shot.JoueurCourant).x,
                            y : master.getPixelPieceFromCoord(master.props.shot.JoueurCourant).y
                        });

    
    });
     this.refs.vertBarre.on('dragstart', function() {
        

        horBarre.position({
                            x : state.xInitHor,
                            y : state.yInitHor
                        });
        joueurCourant.position({
                            x : master.getPixelPieceFromCoord(master.props.shot.JoueurCourant).x,
                            y : master.getPixelPieceFromCoord(master.props.shot.JoueurCourant).y
                        });

    });
    this.refs.horBarre.on('dragend', function() {
        let  newPosX, newPosY;
        if(this.attrs.x<state.tablePixelLignes[0]-state.epaisseurMur
            ||this.attrs.x>state.tablePixelLignes[7]+state.epaisseurMur
            ||this.attrs.y<state.tablePixelLignes[1]-state.epaisseurMur
            ||this.attrs.y>state.tablePixelLignes[8]){
            newPosX=state.xInitHor;
        newPosY= state.yInitHor;

                    
        }
        else{
            for(var i=0;i<10;i++){
                if(Math.abs(state.tablePixelLignes[i]-this.attrs.x)<24){
                    newPosX=state.tablePixelLignes[i];
                }
                if(Math.abs(state.tablePixelLignes[i]-this.attrs.y)<24){
                    newPosY=state.tablePixelLignes[i];
                }
            }
        }

        this.position({
                            x : newPosX,
                            y : newPosY
                        });
        layer.draw();
        if(master.state.varDrag < 1){
            master.send_coord(master.props.shot.idJoueurCourant);
        }
        master.state.varDrag = 1;
    });

        this.refs.vertBarre.on('dragend', function() {
        let  newPosX, newPosY;
        if(this.attrs.y<state.tablePixelLignes[0]-state.epaisseurMur
            ||this.attrs.y>state.tablePixelLignes[7]+state.epaisseurMur
            ||this.attrs.x<state.tablePixelLignes[1]-state.epaisseurMur
            ||this.attrs.x>state.tablePixelLignes[8]){
            newPosX=state.xInitVert;
            newPosY= state.yInitVert;


                    
        }
        else{
            for(var i=0;i<10;i++){
                if(Math.abs(state.tablePixelLignes[i]-this.attrs.x)<24){
                    newPosX=state.tablePixelLignes[i];
                }
                if(Math.abs(state.tablePixelLignes[i]-this.attrs.y)<24){
                    newPosY=state.tablePixelLignes[i];
                }
            }
        }
        this.position({
                            x : newPosX,
                            y : newPosY
                        });
        layer.draw();
        if(master.state.varDrag < 1){
            master.send_coord(master.props.shot.idJoueurCourant);
        }
        master.state.varDrag = 1;
    });
    
  
  }

  componentDidMount() {
     
     console.log(this.props.socket.online_game.joueur);
     if(this.props.socket.online_game.joueur=="VERT"){
        this.state.imageOnline.src = this.state.adresse + "poire.png";
    }
    if(this.props.socket.online_game.joueur=="ORANGE")
        this.state.imageOnline.src = this.state.adresse + "fraise.png"; 

    this.state.image.onload = () => {
      // setState will redraw layer
      // because "image" property is changed
      this.setState({
        image: this.state.image,
        imageFraise: this.state.imageFraise,
        imagePoire: this.state.imagePoire,
        imageOnline: this.state.imageOnline,
        imageCourant: this.state.imageFraise,
        imageAdverse: this.state.imagePoire
    });
  }
  this.updateFunction();
}


render(){

	return(

	<div className="center-block"> 
    <div>{this.props.socket.online_game.adversaire}</div>
    {this.props.socket.type_partie=="online" && <button type="button" onClick={this.componentDidMount.bind(this)}>Appuie pour savoir quel fruit tu es ?</button>}
        
        <Stage width={800} height={500} className="col-md-12">
			<Layer ref="myLayer">
			<Image width={500} height={500} image={this.state.image}/>
			<Rect ref="barre1" x={this.state.listeMursX[0]} y={this.state.listeMursY[0]} width={this.state.listeMursW[0]} height={this.state.listeMursH[0]} fill='brown'/>
			<Rect ref="barre2" x={this.state.listeMursX[1]} y={this.state.listeMursY[1]} width={this.state.listeMursW[1]} height={this.state.listeMursH[1]} fill='brown'/>
			<Rect ref="barre3" x={this.state.listeMursX[2]} y={this.state.listeMursY[2]} width={this.state.listeMursW[2]} height={this.state.listeMursH[2]} fill='brown'/>
			<Rect ref="barre4" x={this.state.listeMursX[3]} y={this.state.listeMursY[3]} width={this.state.listeMursW[3]} height={this.state.listeMursH[3]} fill='brown'/>
			<Rect ref="barre5" x={this.state.listeMursX[4]} y={this.state.listeMursY[4]} width={this.state.listeMursW[4]} height={this.state.listeMursH[4]} fill='brown'/>
			<Rect ref="barre6" x={this.state.listeMursX[5]} y={this.state.listeMursY[5]} width={this.state.listeMursW[5]} height={this.state.listeMursH[5]} fill='brown'/>
			<Rect ref="barre7" x={this.state.listeMursX[6]} y={this.state.listeMursY[6]} width={this.state.listeMursW[6]} height={this.state.listeMursH[6]} fill='brown'/>
			<Rect ref="barre8" x={this.state.listeMursX[7]} y={this.state.listeMursY[7]} width={this.state.listeMursW[7]} height={this.state.listeMursH[7]} fill='brown'/>
			<Rect ref="barre9" x={this.state.listeMursX[8]} y={this.state.listeMursY[8]} width={this.state.listeMursW[8]} height={this.state.listeMursH[8]} fill='brown'/>
			<Rect ref="barre10" x={this.state.listeMursX[9]} y={this.state.listeMursY[9]} width={this.state.listeMursW[9]} height={this.state.listeMursH[9]} fill='brown'/>
			<Rect ref="barre11" x={this.state.listeMursX[10]} y={this.state.listeMursY[10]} width={this.state.listeMursW[10]} height={this.state.listeMursH[10]} fill='brown'/>
			<Rect ref="barre12" x={this.state.listeMursX[11]} y={this.state.listeMursY[11]} width={this.state.listeMursW[11]} height={this.state.listeMursH[11]} fill='brown'/>
			<Rect ref="barre13" x={this.state.listeMursX[12]} y={this.state.listeMursY[12]} width={this.state.listeMursW[12]} height={this.state.listeMursH[12]} fill='brown'/>
			<Rect ref="barre14" x={this.state.listeMursX[13]} y={this.state.listeMursY[13]} width={this.state.listeMursW[13]} height={this.state.listeMursH[13]} fill='brown'/>
			<Rect ref="barre15" x={this.state.listeMursX[14]} y={this.state.listeMursY[14]} width={this.state.listeMursW[14]} height={this.state.listeMursH[14]} fill='brown'/>
			<Rect ref="barre16" x={this.state.listeMursX[15]} y={this.state.listeMursY[15]} width={this.state.listeMursW[15]} height={this.state.listeMursH[15]} fill='brown'/>
			<Rect ref="barre17" x={this.state.listeMursX[16]} y={this.state.listeMursY[16]} width={this.state.listeMursW[16]} height={this.state.listeMursH[16]} fill='brown'/>
			<Rect ref="barre18" x={this.state.listeMursX[17]} y={this.state.listeMursY[17]} width={this.state.listeMursW[17]} height={this.state.listeMursH[17]} fill='brown'/>
			<Rect ref="barre19" x={this.state.listeMursX[18]} y={this.state.listeMursY[18]} width={this.state.listeMursW[18]} height={this.state.listeMursH[18]} fill='brown'/>
			<Rect ref="barre20" x={this.state.listeMursX[19]} y={this.state.listeMursY[19]} width={this.state.listeMursW[19]} height={this.state.listeMursH[19]} fill='brown'/>
	
            <Image image={this.state.imageAdverse} id={this.props.shot.idJoueurAdverse} ref="joueurAdverse" x={this.getPixelPieceFromCoord(this.props.shot.JoueurAdverse).x} y={this.getPixelPieceFromCoord(this.props.shot.JoueurAdverse).y} draggable={false} />
            <Image image={this.state.imageCourant} id={this.props.shot.idJoueurCourant} ref="joueurCourant" x={this.getPixelPieceFromCoord(this.props.shot.JoueurCourant).x} y={this.getPixelPieceFromCoord(this.props.shot.JoueurCourant).y} draggable={true} />
            
        
			<Text fontSize={15} x={550} y={50} text={this.props.shot.messageTour}/>
            {this.props.socket.type_partie=="local" && <Image image={this.state.imageCourant} x={725} y={40} />}
            {this.props.socket.type_partie=="online" && <Text fontSize={15} x={550} y={70} text="Tu es le joueur :"/>}
            {this.props.socket.type_partie=="online" && <Image image={this.state.imageOnline} x={675} y={60} />}
            <Text fontSize={20} fill='red' x={550} y={100} text={this.props.shot.mursRestantsOrange}/>
            <Text fontSize={20} fill='green' x={550} y={150} text={this.props.shot.mursRestantsVert}/>

			<Rect ref="vertBarre" x={this.state.xInitVert} y={this.state.yInitVert} width={this.state.epaisseurMur} height={this.state.longueurMur} fill= 'brown' draggable={true}/>
			<Rect ref="horBarre"  x={this.state.xInitHor} y={this.state.yInitHor} width={this.state.longueurMur} height={this.state.epaisseurMur} fill= 'brown' draggable={true}/>
			
			</Layer>

		</Stage>

        <div className="col-md-8">{this.state.messageErreur!="" ? <div className="alert alert-danger fixed=bottom" >{this.state.messageErreur}</div>:null}</div>
	</div>
		);


	


	}	
}
const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket,
        shot: state.shotReducer.shot
 } 
};

export default connect(mapStateToProps)(Plateau);