import React, { Component } from 'react';
import './register.css';
import '../../lib/bootstrap-3.3.7-dist/css/bootstrap.min.css';
import {connect} from 'react-redux';
import {setSocket} from '../../actions/actions';


class Register extends Component {
	constructor(props) {
        super(props);

        this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);

		    this.state = { 
			username: '',
			password: '', 
			email:'',
			passwordVerif:'',
			errorMessage:'',
			successMessage:false
		}; 
    }

	componentDidMount(){
		var master=this;
		this.props.socket.masocket.on('successRegister', function(data){
		
			console.log('Success Register !!');
			master.setState({successMessage:true});
			

			

		});
		this.props.socket.masocket.on('failRegister', function(data){
		
			console.log('Fail Register !!');
			master.setState({errorMessage:data});

		});
	}

	handleChange(key) {
	
	return function (e) {
      var state = {};
      state[key] = e.target.value;
      this.setState(state);
     }.bind(this);
  }
  handleSubmit(event){

  	event.preventDefault();
  	this.setState({errorMessage:'',successMessage:false});
  	var userReg={username:this.state.username, email:this.state.email, password:this.state.password,passwordVerif:this.state.passwordVerif};
	
	this.props.socket.masocket.emit('register',userReg);
	//this.props.dispatch(setSocket(this.props.socket));
	
  }

render(){
	return(
		<div className='span8 main'>
		<h1>Register</h1>
		<form onSubmit={this.handleSubmit}  >
					<div className="form-group">
					<input type="email" name="email" placeholder="Email" value={this.state.email} 
                onChange={this.handleChange('email')}/>
			</div>
			<div className="form-group">

				<input type="text" name="username" placeholder="Username"  value={this.state.username} 
                onChange={this.handleChange('username')}/>
					 </div >

			<div className="form-group">
					<input type="password" name="password" placeholder="Password" value={this.state.password} 
                onChange={this.handleChange('password')}/>
			</div>
						<div className="form-group">
					<input type="password" name="password" placeholder="Password" value={this.state.passwordVerif} 
                onChange={this.handleChange('passwordVerif')}/>
			</div>



			<input type="submit" name="register" value="Register"/>

	</form>
	{ this.state.errorMessage!='' ? <div className="alert alert-danger" >{this.state.errorMessage} </div> :null}
	{ this.state.successMessage ? <div className="alert alert-success" >Vous avez été correctement enregistré, vous pouvez maintenant vous connecter !</div> :null}
	</div>
		);
	}	
}

const mapStateToProps = (state, ownProps) => {
    return {
        socket: state.socketReducer.socket
 } 
};

export default connect(mapStateToProps)(Register);
